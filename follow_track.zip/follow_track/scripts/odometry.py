# -*- coding: utf-8 -*-
"""车体位姿积分：给卡尔曼提供世界系参考。

为什么需要它
    卡尔曼的状态如果建在车体系（x 前、y 左），车一开动整个坐标系就跟着
    平移旋转，静止目标在车体系下的坐标会随之突变。马氏门控把这些"突变"
    当成野值全部拒绝，真机实测 10 秒内拒绝数 6 -> 147、接受数不再增长，
    控制随即失效（表现为车走几秒后彻底不动）。

    把状态搬进世界系后，匀速模型重新成立：人不动，世界坐标就不动。

精度
    这台车 hall_encoder=false，没有可靠轮式里程计。位姿由已发指令按自行车
    模型开环积分得到，会有累积漂移；但观测是直接从深度图测出的世界坐标，
    漂移会被每次更新拉回来。短时间内（几十秒）足够。
"""

import math


class Odometry(object):
    def __init__(self, wheelbase=0.315):
        self.wheelbase = float(wheelbase)
        self.x = 0.0
        self.y = 0.0
        self.th = 0.0
        self.t = None
        self.v = 0.0
        self.delta = 0.0

    def reset(self):
        self.x = self.y = self.th = 0.0
        self.t = None
        self.v = self.delta = 0.0

    def predict(self, t):
        """把位姿积分到时刻 t。dt 封顶 0.2 s，避免卡顿后一次跳很远。"""
        if self.t is None:
            self.t = t
            return
        dt = t - self.t
        self.t = t
        if dt <= 0.0:
            return
        dt = min(dt, 0.20)
        v = self.v
        if abs(v) < 1e-4:
            return
        dth = v * dt * math.tan(self.delta) / self.wheelbase
        th_mid = self.th + 0.5 * dth
        self.x += v * dt * math.cos(th_mid)
        self.y += v * dt * math.sin(th_mid)
        self.th += dth

    def set_cmd(self, v, delta):
        self.v = float(v)
        self.delta = float(delta)

    def to_world(self, xb, yb):
        c, s = math.cos(self.th), math.sin(self.th)
        return self.x + c * xb - s * yb, self.y + s * xb + c * yb

    def to_body(self, xw, yw):
        c, s = math.cos(self.th), math.sin(self.th)
        dx, dy = xw - self.x, yw - self.y
        return c * dx + s * dy, -s * dx + c * dy

    def vec_to_body(self, vxw, vyw):
        c, s = math.cos(self.th), math.sin(self.th)
        return c * vxw + s * vyw, -s * vxw + c * vyw
