# -*- coding: utf-8 -*-
"""S4 真机节点：感知线程 + 30 Hz 控制线程 + 阿克曼指令发布。

安全设计（按重要性排序）
    1. 默认 dry-run：不加 --enable 只打印指令，绝不发布
    2. 启动后 arm_delay 秒内强制零速，留出人工反应时间
    3. 退出（含异常）时一定发零速，并持续发到进程结束
    4. 观测超过 stale_time 未更新 -> reliable 降级 -> 控制器 HOLD
    5. 目标在后方 / 迎面走来 / 过近 -> HOLD，不靠 v_min 硬顶

架构
    感知线程  取帧 -> 检测 -> 跟踪 -> 3D 定位 -> 卡尔曼更新（约 15 Hz）
    控制线程  卡尔曼预测到当前时刻 -> 控制律 -> 发布（30 Hz）

为什么必须异步：检测单帧约 47 ms，30 Hz 的周期只有 33 ms。串行循环
只能跑到 20 Hz 且抖动大；异步后控制节拍稳定，检测慢只是观测变稀疏，
卡尔曼在中间补位。

用法
    # 只打印，不发指令（默认）
    ~/follow/venv/bin/python scripts/s4_live.py --duration 30

    # 真的发指令（首次务必垫起车轮）
    ~/follow/venv/bin/python scripts/s4_live.py --enable --vmax 0.20 --duration 20
"""

import argparse
import json
import math
import os
import queue
import sys
import threading
import time

import numpy as np
import rospy
from cv_bridge import CvBridge
from sensor_msgs.msg import CameraInfo, Image, LaserScan

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "vendor"))

os.environ.setdefault("YOLO_CONFIG_DIR", os.path.join(ROOT, "runtime", "ultralytics"))
os.makedirs(os.environ["YOLO_CONFIG_DIR"], exist_ok=True)

import compat  # noqa: F401  # 必须在导入 yolox 之前
import cv2  # noqa: E402

from detector import PersonDetector  # noqa: E402
from tracker import PersonTracker, TargetSelector  # noqa: E402
from depth_locator import DepthLocator, camera_to_base  # noqa: E402
from track_state import TrackFilter  # noqa: E402
from follow_control import FollowController  # noqa: E402
from odometry import Odometry  # noqa: E402
from lidar_fusion import LidarFusion  # noqa: E402
from vision_verify import VisionVerifier  # noqa: E402
import depth_viz  # noqa: E402

try:
    from ackermann_msgs.msg import AckermannDriveStamped
except ImportError:      # 没装 ackermann_msgs 时仍可 dry-run
    AckermannDriveStamped = None

DEFAULT_EXTRINSIC = (0.160, 0.0325, 0.242, (-1.5707963, 0.0, -1.5707963))
PANEL_W, PANEL_H = 640, 480

# 相机水平 FOV（度）。D435 640 宽，fx≈606，水平 FOV = 2*atan(320/606) ≈ 55.6°，
# 但按整幅归一化到 ±34.5° 已够用；这里取一个近似值供角度先验。
CAM_FOV_DEG = 55.0

# 雷达位置门半径（米）。视觉锚点很准，预热时用紧门，只认距离视觉给的
# 位置足够近的簇，超出就拒绝，不主动"猜"哪个是人。宁可跟丢也不锁错。
POS_GATE_WARM = 0.40
# 接管门：航迹自连续，单帧最大位移约 22 cm。0.45 留足余量；防锁错主要靠
# 静态检测 + 视觉佐证，而不是把门卡死（门太紧会连正常目标都锁不住）。
POS_GATE_LOST = 0.45

# 雷达观测的标准差。簇中心落在腿的前沿，与深度测的身体表面有系统差，
# 噪声明显大于深度的 0.08。给小了会被马氏门当野值拒掉，等于没接管。
LIDAR_OBS_STD = 0.15

# 雷达接管上限：超过这个秒数没有视觉确认，说明航迹可能已经跟错
# （人走远、锁到桌腿、换成别人），必须放弃并交回视觉。
VISION_TIMEOUT = 10.0

# 视觉重捕后 ID 变了，若新观测离卡尔曼当前估计在这个距离内，
# 判为同一个人（重捕而非换人）。放宽到 3 m：开环里程计跟久了会漂，
# 加上目标本身走动的余量，1.5 m 偏紧。
RELINK_DIST = 3.0

# 方位角兜底判据：雷达目标方位与新框方位差在此范围内即判为同一人。
# 相机与雷达安装位置不同有 3~6° 系统偏差，取 15° 容差。
RELINK_ANGLE_DEG = 15.0

# 跟丢后的主动搜索：沿雷达最后轨迹方向外推一个虚拟点，车开过去找。
# 外推距离 1.5 m（约一次转弯弧长），最多持续 3 s，超时仍无重捕则停车。
SEARCH_AHEAD = 1.5
SEARCH_TIME = 7.0
SEARCH_OBS_STD = 0.50


def bbox_cam_angle(bbox, frame_w):
    """由目标 bbox 中心算相机方位角（画面中心 0°，左负右正，度）。"""
    x1, y1, x2, y2 = bbox[:4]
    cx = (x1 + x2) / 2.0
    return (cx - frame_w / 2.0) / frame_w * CAM_FOV_DEG

C_GREEN = (0, 255, 0)
C_GRAY = (150, 150, 150)
C_MAGENTA = (255, 0, 255)
C_YELLOW = (0, 255, 255)
C_RED = (0, 0, 255)
C_WHITE = (255, 255, 255)


class FramePair(object):
    """彩色/深度配对。以彩色帧为触发，取时间最近的深度帧。"""

    def __init__(self, max_dt=0.10):
        self.lock = threading.Lock()
        self.bridge = CvBridge()
        self.color = None
        self.color_t = 0.0
        self.depth = None
        self.depth_t = 0.0
        self.K = None
        self.max_dt = max_dt
        self.taken_color_t = 0.0

    def on_color(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception:
            return
        with self.lock:
            self.color = img
            self.color_t = msg.header.stamp.to_sec()

    def on_depth(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, msg.encoding)
        except Exception:
            return
        with self.lock:
            self.depth = img
            self.depth_t = msg.header.stamp.to_sec()

    def on_info(self, msg):
        with self.lock:
            self.K = (msg.K[0], msg.K[4], msg.K[2], msg.K[5])

    def get(self):
        with self.lock:
            if self.color is None or self.depth is None or self.K is None:
                return None
            if self.color_t <= self.taken_color_t:
                return None
            if abs(self.color_t - self.depth_t) > self.max_dt:
                return None
            self.taken_color_t = self.color_t
            color = self.color.copy()
            d = self.depth
            u16 = d.copy() if d.dtype == np.uint16 else None
            depth = d.astype(np.float32) * 0.001 if d.dtype == np.uint16 else d.astype(np.float32)
            # 统一用 wall clock：控制线程也用 time.time()，混用 ROS stamp 会让 dt 出错
            return color, depth, u16, self.K, time.time()


def depth_to_color(depth, d_min=0.3, d_max=3.0):
    inv = (depth <= 0.0) | (depth > d_max)
    norm = np.clip((depth - d_min) / max(1e-6, (d_max - d_min)), 0.0, 1.0)
    gray = (norm * 255.0).astype(np.uint8)
    color = cv2.applyColorMap(gray, cv2.COLORMAP_JET)
    color[inv] = (20, 20, 20)
    return color


def draw_hud(img, lines, x=8, y=22, color=C_WHITE, scale=0.48, dy=19):
    for i, s in enumerate(lines):
        cv2.putText(img, s, (x, y + i * dy), cv2.FONT_HERSHEY_SIMPLEX,
                    scale, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(img, s, (x, y + i * dy), cv2.FONT_HERSHEY_SIMPLEX,
                    scale, color, 1, cv2.LINE_AA)


class VideoSink(object):
    """异步写视频。

    写 1920x480 的帧要几毫秒，且 mp4v 编码抖动大；直接放感知线程里会把
    检测帧率从 15 Hz 拖到 10 Hz 以下，控制线程拿到的是变稀的观测。
    这里用长度 3 的队列，写不过来就丢帧 —— 视频少几帧没关系，
    控制节拍不能掉。
    """

    def __init__(self, path, size, fps=15.0, maxlen=3):
        self.writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"),
                                      fps, size)
        self.ok = self.writer.isOpened()
        self.q = queue.Queue(maxsize=maxlen)
        self.dropped = 0
        self.fail = ""
        if self.ok:
            self.th = threading.Thread(target=self._run)
            self.th.daemon = True
            self.th.start()

    def _run(self):
        while True:
            frame = self.q.get()
            if frame is None:
                break
            try:
                self.writer.write(frame)
            except Exception as exc:      # 编码器异常不能让感知线程死
                self.fail = str(exc)
                break

    def write(self, frame):
        if not self.ok:
            return
        try:
            self.q.put_nowait(frame)
        except queue.Full:
            self.dropped += 1

    def close(self):
        self.ok = False               # 先关闸，感知线程的后续调用直接返回
        if not getattr(self, "th", None):
            self.writer.release()
            return
        try:
            self.q.put(None, timeout=2.0)
        except queue.Full:
            pass
        self.th.join(timeout=3.0)
        self.writer.release()


class Stats(object):
    """逐帧关键数据：CSV 落盘，退出时汇总成 JSON。"""

    COLS = ("t state id persons det_ms raw_z roi_pts width_m "
            "kf_x kf_y d v delta_deg omega mode reliable acc rej src").split()

    def __init__(self, path=None):
        self.path = path
        self.fh = None
        self.rows = 0
        if path:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            self.fh = open(path, "w")
            self.fh.write(",".join(self.COLS) + "\n")

        self.t0 = time.time()
        self.ds = []            # TRACK 时的车体系距离
        self.vs = []
        self.raw_zs = []
        self.roi = []
        self.modes = {}
        self.acc = 0
        self.rej = 0
        self.frames = 0

    def add(self, t, state, tid, persons, det_ms, res, st, cmd, d, kf_acc=0, kf_rej=0, src="-"):
        self.frames += 1
        raw_z = res.Z if (res is not None and res.valid) else float("nan")
        roi_pts = res.n_points if res is not None else 0
        width_m = res.width_m if (res is not None and res.valid) else float("nan")
        kx = st["x"] if st.get("initialized") else float("nan")
        ky = st["y"] if st.get("initialized") else float("nan")
        mode = cmd["mode"] if cmd else "-"
        v = cmd["v"] if cmd else 0.0
        delta = math.degrees(cmd["delta"]) if cmd else 0.0
        omega = cmd["omega"] if cmd else 0.0
        rel = 1 if (cmd and cmd["reliable"]) else 0

        if self.fh is not None:
            self.fh.write("%.3f,%s,%s,%d,%.1f,%.3f,%d,%.3f,%.3f,%.3f,%.3f,"
                          "%.3f,%.2f,%.3f,%s,%d,%d,%d,%s\n"
                          % (t - self.t0, state,
                             "-" if tid is None else tid, persons, det_ms,
                             raw_z, roi_pts, width_m, kx, ky,
                             d, v, delta, omega, mode, rel, kf_acc, kf_rej, src))
            self.rows += 1

        if state == "TRACK" and d > 0:
            self.ds.append(d)
            self.vs.append(v)
            self.modes[mode] = self.modes.get(mode, 0) + 1
        if res is not None and res.valid:
            self.raw_zs.append(res.Z)
            self.roi.append(res.n_points)
        if kf_acc or kf_rej:
            self.acc, self.rej = int(kf_acc), int(kf_rej)

    def summary(self):
        def pct(a, p):
            if not a:
                return None
            a = sorted(a)
            i = min(len(a) - 1, max(0, int(round((len(a) - 1) * p))))
            return round(a[i], 3)

        dur = time.time() - self.t0
        return {
            "duration_s": round(dur, 2),
            "frames": self.frames,
            "perception_fps": round(self.frames / dur, 2) if dur > 0 else 0,
            "csv_rows": self.rows,
            "dist_m": {
                "first": self.ds[0] if self.ds else None,
                "last": self.ds[-1] if self.ds else None,
                "min": round(min(self.ds), 3) if self.ds else None,
                "max": round(max(self.ds), 3) if self.ds else None,
                "median": pct(self.ds, 0.5),
            },
            "speed_mps": {
                "median": pct(self.vs, 0.5),
                "max": round(max(self.vs), 3) if self.vs else None,
                "mean": round(sum(self.vs) / len(self.vs), 3) if self.vs else None,
            },
            "raw_z_median": pct(self.raw_zs, 0.5),
            "roi_points_median": pct(self.roi, 0.5),
            "mode_counts": self.modes,
            "kf_accepted": self.acc,
            "kf_rejected": self.rej,
            "kf_accept_ratio": (round(self.acc / float(self.acc + self.rej), 3)
                                if (self.acc + self.rej) else None),
        }

    def close(self):
        if self.fh is not None:
            self.fh.close()
            self.fh = None


class Shared(object):
    """感知线程与控制线程之间的唯一共享状态。"""

    def __init__(self, sigma_obs, q_acc, vmax):
        self.lock = threading.RLock()
        self.kf = TrackFilter(sigma_obs=sigma_obs, q_acc=q_acc, max_speed=vmax)
        self.ctrl = FollowController(v_max=vmax)
        self.odom = Odometry()
        self.state = "INIT"          # INIT / SEARCH / TRACK / LOST / ESTOP
        self.locked_id = None
        self.obs_time = 0.0          # 最近一次有效观测的时间
        self.last_cmd = None
        self.frames = 0
        self.det_ms = 0.0
        self.last_frame = None       # 供可视化
        self.stop_reason = ""
        self.writer = None
        self.stats = None
        self.K = None                # 相机内参，点云面板反投影用
        self.trail = []              # 世界系轨迹，画点云面板用
        self.lidar = LidarFusion()   # 雷达腿簇融合
        self.verifier = VisionVerifier()  # 视觉佐证：雷达目标是否落在 person 框内
        self.fused_src = "depth"     # 本帧观测来源：depth / lidar / none
        self.last_depth_t = 0.0      # 最近一次视觉确认的时刻（雷达接管计时用）
        self.search_start_t = 0.0    # 主动搜索起始时刻，0 表示未在搜索


def draw_lidar(pts, clusters, locked=None, scale=140.0):
    """雷达俯视图：车在中心，X 前 Y 左。灰=原始点，黄=腿簇，绿=锁定簇。"""
    img = np.full((PANEL_H, PANEL_W, 3), (28, 26, 24), dtype=np.uint8)
    cx0, cy0 = PANEL_W // 2, PANEL_H // 2
    # 网格
    for g in range(-2, 3):
        px = cx0 + g * scale
        cv2.line(img, (int(px), 0), (int(px), PANEL_H), (50, 48, 44), 1)
        py = cy0 - g * scale
        cv2.line(img, (0, int(py)), (PANEL_W, int(py)), (50, 48, 44), 1)
    # 距离弧
    for rr in (1, 2):
        cv2.circle(img, (cx0, cy0), int(rr * scale), (60, 58, 54), 1)

    def to_px(x, y):
        return int(cx0 + x * scale), int(cy0 - y * scale)

    # 车体
    cv2.rectangle(img, (cx0 - 8, cy0 - 6), (cx0 + 8, cy0 + 6), (255, 180, 60), -1)
    cv2.line(img, (cx0, cy0), (cx0 + int(0.5 * scale), cy0), (255, 180, 60), 2)

    # 原始点（灰）
    for x, y in pts:
        px, py = to_px(x, y)
        if 0 <= px < PANEL_W and 0 <= py < PANEL_H:
            img[py, px] = (110, 110, 110)

    # 腿簇（黄框 + 编号）
    for i, (cx, cy, r, ang, w, n) in enumerate(clusters):
        px, py = to_px(cx, cy)
        cv2.circle(img, (px, py), 6, (0, 220, 220), 1)
        cv2.putText(img, "%d" % i, (px + 6, py - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 220, 220), 1, cv2.LINE_AA)

    # 锁定的簇（绿，加粗）
    if locked is not None:
        lx, ly, lr = locked
        px, py = to_px(lx, ly)
        cv2.circle(img, (px, py), 10, (0, 255, 0), 2)
        cv2.putText(img, "LOCK %.2fm" % lr, (px - 30, py - 14),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2, cv2.LINE_AA)

    draw_hud(img, ["LIDAR  top-view  1m grid", "clusters=%d" % len(clusters)],
             color=(200, 200, 200), scale=0.42, dy=17)
    return img


def draw_debug(color, depth, tracks, target, locator, prior_d, st, res, shared,
               tgt_base=None, trail_base=None):
    """三画面：彩色检测 | 对齐深度（选中点在 ROI 内） | 点云斜视图。"""
    left = color.copy()
    right = depth_to_color(depth)

    x1 = y1 = x2 = y2 = None
    for tid, tlbr, _ in tracks:
        if tid == shared.locked_id:
            continue
        bx1, by1, bx2, by2 = [int(round(v)) for v in tlbr[:4]]
        cv2.rectangle(left, (bx1, by1), (bx2, by2), C_GRAY, 1)

    if target is not None:
        x1, y1, x2, y2 = [int(round(v)) for v in target[1][:4]]
        cv2.rectangle(left, (x1, y1), (x2, y2), C_GREEN, 2)
        cv2.rectangle(right, (x1, y1), (x2, y2), C_GREEN, 2)
        # 下半框是取深度的那部分，画出来才能解释"为什么算的是这个距离"
        y_top = int(y1 + (y2 - y1) * (1.0 - locator.lower_ratio))
        cv2.line(left, (x1, y_top), (x2, y_top), C_YELLOW, 1)
        cv2.line(right, (x1, y_top), (x2, y_top), C_YELLOW, 1)
        # ID 不再画在框顶（人靠近时框顶出画，文字会被裁掉），改到左侧 HUD 固定行
        mask, _ = locator.collect_mask(target[1], depth, prior_d=prior_d)
        if mask.any():
            right[mask] = C_MAGENTA
    else:
        mask = None

    cmd = shared.last_cmd
    state = shared.state
    sc = C_GREEN if state == "TRACK" else (C_YELLOW if state == "SEARCH" else C_RED)

    lines_l = [state, "persons=%d" % len(tracks),
               "det=%.1fms" % shared.det_ms]
    lines_l.append(("ID #%d" % target[0]) if target is not None else "ID ---")
    if res is not None and getattr(res, "valid", False):
        lines_l.append("RAW Z=%.2f m" % res.Z)

    if cmd is not None:
        # OpenCV 的 putText 不支持中文，HUD 一律用英文
        lines_r = ["CMD  %s" % cmd["mode"],
                   "v   %.2f m/s" % cmd["v"],
                   "del %+5.1f deg" % np.degrees(cmd["delta"]),
                   "omg %+.2f rad/s" % cmd["omega"],
                   "rel %s" % ("OK" if cmd["reliable"] else "WEAK")]
        rc = C_GREEN if cmd["v"] > 0 else C_YELLOW
    else:
        lines_r = ["CMD  ---"]
        rc = C_YELLOW

    if st is not None and st.get("initialized"):
        # 状态在世界系，画面要显示车体系距离
        bx, by = shared.odom.to_body(st["x"], st["y"])
        lines_r.append("d=%.2f std=%.3f" % (np.hypot(bx, by), st["pos_std"]))

    draw_hud(left, lines_l, color=sc, scale=0.45, dy=18)
    draw_hud(right, lines_r, color=rc, scale=0.45, dy=18)

    cloud_txt = ""
    if res is not None and getattr(res, "valid", False):
        cloud_txt = "Z=%.2f  n=%d  w=%.2f" % (res.Z, res.n_points, res.width_m)
    extra = [("%s  v=%.2f" % (cmd["mode"], cmd["v"])) if cmd else "CMD ---"]
    if st is not None and st.get("initialized") and tgt_base is not None:
        extra.append("d=%.2f  std=%.3f" % (np.hypot(tgt_base[0], tgt_base[1]),
                                           st["pos_std"]))
    if shared.K is None:
        cloud = np.full((PANEL_H, PANEL_W, 3), 25, dtype=np.uint8)
    else:
        cloud = depth_viz.render(depth, shared.K, DEFAULT_EXTRINSIC,
                                 mask=mask, tgt=tgt_base, trail=trail_base,
                                 pts_text=cloud_txt, extra=extra)

    # ---- 雷达面板：原始点 + 腿簇 + 跟踪中的簇 ----
    lidar_pts, lidar_clusters = shared.lidar.snapshot()
    lidar_locked = None
    txy = shared.lidar.track_xy
    if txy is not None:
        # 航迹一直在跟（不管是视觉预热还是雷达接管），都圈出来。
        # 之前只在 fused_src=="lidar" 时画，且依赖 tgt_base（深度结果），
        # 导致雷达接管时恰恰看不到圈。
        lidar_locked = (txy[0], txy[1], math.hypot(txy[0], txy[1]))
    lidar_panel = draw_lidar(lidar_pts, lidar_clusters, locked=lidar_locked)

    # 四宫格 2x2：左上 RGB，右上深度，左下点云，右下雷达
    canvas = np.zeros((PANEL_H * 2, PANEL_W * 2, 3), dtype=np.uint8)
    canvas[:PANEL_H, :PANEL_W] = left
    canvas[:PANEL_H, PANEL_W:] = right
    canvas[PANEL_H:, :PANEL_W] = cloud
    canvas[PANEL_H:, PANEL_W:] = lidar_panel
    cv2.line(canvas, (0, PANEL_H), (PANEL_W * 2, PANEL_H), (60, 60, 60), 1)
    cv2.line(canvas, (PANEL_W, 0), (PANEL_W, PANEL_H * 2), (60, 60, 60), 1)
    return canvas


def perception_loop(args, pair, shared, stop_evt):
    detector = PersonDetector(args.model, imgsz=args.imgsz, conf=args.conf)
    tracker = PersonTracker(track_thresh=args.conf, track_buffer=30, frame_rate=30)
    selector = TargetSelector(max_lost=args.max_lost, lock_confirm=3,
                              cooldown=5, min_area_ratio=0.01,
                              in_frame_ratio=0.60,
                              image_size=(PANEL_H, PANEL_W))
    locator = DepthLocator(lower_ratio=args.lower_ratio,
                           max_width=args.max_width,
                           min_points=args.min_points)

    last_z = None
    prev_id = None
    JUMP_GATE = 0.80
    EMA_ALPHA = 0.50
    t_start = time.time()
    n_miss = 0

    while not stop_evt.is_set() and not rospy.is_shutdown():
        if args.duration > 0 and time.time() - t_start > args.duration:
            break

        got = pair.get()
        if got is None:
            n_miss += 1
            time.sleep(0.002)
            if n_miss > 1500:
                shared.stop_reason = "无相机数据"
                print("[S4] 超过 3 秒未收到配对帧，检查相机是否启动")
                break
            continue

        color, depth, u16, K, stamp = got
        n_miss = 0

        t0 = time.time()
        dets = detector.detect(color)
        ms = (time.time() - t0) * 1000.0
        tracks = tracker.update(dets, color.shape)

        pre_res = None
        if selector.locked_id is not None:
            cur = None
            for tr in tracks:
                if tr[0] == selector.locked_id:
                    cur = tr
                    break
            if cur is not None and selector._in_frame(cur[1]):
                pre_res = locator.locate(cur[1], depth, K, prior_d=last_z)
        has_depth = bool(pre_res is not None and pre_res.valid)

        target, _ = selector.update(tracks, has_depth_obs=has_depth,
                                    frame_shape=color.shape, image=color)

        prior_used = last_z
        res = pre_res
        if target is not None and res is None:
            res = locator.locate(target[1], depth, K, prior_d=prior_used)

        if res is not None and res.valid:
            if last_z is None:
                last_z = res.Z
            elif abs(res.Z - last_z) <= JUMP_GATE:
                last_z = last_z + EMA_ALPHA * (res.Z - last_z)

        obs_body = None
        fused_src = "none"
        if res is not None and res.valid:
            Xb, Yb, _ = camera_to_base(res.X, res.Y, res.Z, DEFAULT_EXTRINSIC)
            obs_body = (Xb, Yb)
            fused_src = "depth"
            shared.search_start_t = 0.0
            shared.verifier.reset()
            # 预热雷达航迹：视觉给的锚点直接拿去匹配雷达簇，
            # 视觉丢的那一刻航迹已经是热的，接管时无冷启动。
            # 视觉在线，锚点准，不做动静过滤（避免误杀站定的人）。
            # 若雷达航迹残留的位置离视觉锚点太远（之前锁错了桌腿等），
            # 先清掉航迹，让 match_xy 用视觉锚点重新初始化，避免门中心错位。
            if shared.lidar.track_xy is not None:
                d_anchor = math.hypot(shared.lidar.track_xy[0] - Xb,
                                      shared.lidar.track_xy[1] - Yb)
                if d_anchor > 0.5:
                    shared.lidar.drop_keep_history()
            shared.lidar.match_xy(Xb, Yb, gate=POS_GATE_WARM,
                                  use_motion_filter=False)
        else:
            # 视觉不可用。先用雷达航迹硬跟；航迹断了就沿最后轨迹方向
            # 外推一个虚拟点，让车开过去找，而不是原地等人回来。
            matched = None
            if shared.lidar.track_ok():
                # 视觉丢失、雷达独立找目标：启用动静过滤，排除桌腿/墙柱
                matched = shared.lidar.match_xy(0.0, 0.0, gate=POS_GATE_LOST,
                                               use_motion_filter=True)
            if matched is not None:
                # 视觉佐证：雷达目标投到图像，看是否落在某个 person 框里。
                # 不在框内连续多帧，说明可能锁到桌腿/柱子，作废这条航迹。
                boxes = [t[1] for t in tracks]
                if K is not None and shared.verifier.check(
                        matched["Xb"], matched["Yb"], boxes,
                        DEFAULT_EXTRINSIC, K):
                    obs_body = (matched["Xb"], matched["Yb"])
                    fused_src = "lidar"
                    shared.search_start_t = 0.0
                else:
                    # 佐证失败：可能锁到桌腿。停跟随但保留轨迹历史，
                    # 供下方的外推搜索继续使用，而不是彻底放弃。
                    shared.lidar.drop_keep_history()
                    obs_body = None
                    fused_src = "none"
            else:
                if shared.search_start_t <= 0.0:
                    shared.search_start_t = time.time()
                if time.time() - shared.search_start_t < SEARCH_TIME:
                    ex = shared.lidar.extrapolate(ahead=SEARCH_AHEAD)
                    if ex is not None:
                        obs_body = ex
                        fused_src = "search"

        # 视觉确认计时：只用于诊断，不再用 VISION_TIMEOUT 去 reset 雷达航迹。
        # 之前"超时就 reset_track()"会把 history 一起清掉，导致后续 search
        # 的 extrapolate 永远返回 None，车彻底停住。正确做法是：视觉丢失后
        # 雷达 + search 持续工作，直到视觉回来；中间不主动清空历史。
        now_t = time.time()
        if fused_src == "depth":
            shared.last_depth_t = now_t
        cur_id = selector.locked_id
        # 时间基准必须与控制线程一致（wall clock）。相机 stamp 是曝光时刻，
        # 比到达时刻早约一个帧间隔，混用会让卡尔曼算出 dt<=0，预测失效。
        obs_t = time.time()
        with shared.lock:
            # 观测从车体系换到世界系：卡尔曼的匀速模型只在世界系里成立。
            # 必须在换 ID 判定之前算好，因为判定要用它比位置。
            obs_xy = None
            if obs_body is not None:
                wx, wy = shared.odom.to_world(obs_body[0], obs_body[1])
                obs_xy = np.array([wx, wy])

            if prev_id is not None and cur_id != prev_id:
                # 只跟一个人。ID 变了有两种可能：
                #   1) 同一人被重捕，ByteTrack 重新编号 —— 位置仍在估计附近
                #   2) 换成了另一个人 —— 位置明显跳开
                # 情况 1 允许续接；情况 2 直接终止，绝不换目标。
                relink = False
                if obs_xy is not None and shared.kf.initialized:
                    d_id = float(np.hypot(obs_xy[0] - shared.kf.x[0],
                                          obs_xy[1] - shared.kf.x[1]))
                    relink = d_id < RELINK_DIST
                # 方位角判据：雷达跟踪目标的方位，与新 ID 框的方位比较。
                # 纯几何，不依赖车轮里程计，长时间跟随后不会因漂移误判。
                if not relink and shared.lidar.track_xy is not None:
                    txy = shared.lidar.track_xy
                    ang_lidar = math.degrees(math.atan2(txy[1], txy[0]))
                    for t in tracks:
                        if t[0] != cur_id:
                            continue
                        # bbox_cam_angle 右为正，车体系 Y 左为正，取反对齐
                        ang_cam = -bbox_cam_angle(t[1], color.shape[1])
                        if abs(ang_lidar - ang_cam) < RELINK_ANGLE_DEG:
                            relink = True
                        break
                if not relink:
                    selector.freeze()
                    shared.stop_reason = "目标已切换，停止跟随"
                    shared.kf.reset(t=obs_t)
                    shared.ctrl.reset()
                    if obs_xy is not None:
                        obs_xy = None
            prev_id = cur_id

            st = shared.kf.step(obs_t, obs_xy,
                                obs_std=(LIDAR_OBS_STD if fused_src == "lidar"
                                         else (SEARCH_OBS_STD
                                               if fused_src == "search"
                                               else args.sigma_obs)))
            if obs_xy is not None and st["accepted"]:
                shared.obs_time = obs_t

            shared.locked_id = cur_id
            shared.frames += 1
            shared.det_ms = ms
            shared.K = K
            shared.fused_src = fused_src

            # 状态只看"这一帧有没有有效观测"，不再依赖 locked_id。
            # locked_id 是视觉的副产物，视觉丢失后它必然清空，
            # 若拿它当状态依据，雷达接管永远触发不了。
            if fused_src == "depth":
                shared.state = "TRACK"
            elif fused_src == "lidar":
                shared.state = "TRACK_LIDAR"
            elif fused_src == "search":
                shared.state = "SEARCH_TRACK"
            elif cur_id is None:
                shared.state = "SEARCH"
            else:
                shared.state = "LOST"

            # 轨迹存世界系，画的时候再换到当前车体系，否则车一转弯整条轨迹会跟着转
            if obs_xy is not None and st["accepted"]:
                shared.trail.append((float(obs_xy[0]), float(obs_xy[1])))
                if len(shared.trail) > 400:
                    del shared.trail[:100]

            tgt_base = None
            trail_base = None
            if res is not None and res.valid:
                tgt_base = camera_to_base(res.X, res.Y, res.Z, DEFAULT_EXTRINSIC)
            trail_base = [shared.odom.to_body(x, y) for x, y in shared.trail]
            cmd_now = shared.last_cmd

            if args.visual:
                shared.last_frame = (color, depth, tracks, target, locator, prior_used, st, res)

        # 绘图放在锁外，避免写视频阻塞 30 Hz 控制线程
        writer = shared.writer
        if writer is not None:
            try:
                writer.write(draw_debug(color, depth, tracks, target, locator,
                                        prior_used, st, res, shared,
                                        tgt_base=tgt_base, trail_base=trail_base))
            except Exception as exc:
                print("[S4] 可视化失败: %s" % exc)

        stats = shared.stats
        if stats is not None:
            d_now = 0.0
            if st.get("initialized"):
                bx, by = shared.odom.to_body(st["x"], st["y"])
                d_now = math.hypot(bx, by)
            kf = shared.kf
            kf_acc = getattr(kf, "cum_n_update", 0) + getattr(kf, "n_update", 0)
            kf_rej = getattr(kf, "cum_n_gate_reject", 0) + getattr(kf, "n_gate_reject", 0)
            stats.add(obs_t, shared.state, cur_id, len(tracks), ms,
                      res, st, cmd_now, d_now, kf_acc, kf_rej, src=fused_src)


def control_loop(args, shared, pub, stop_evt):
    rate_hz = args.rate
    period = 1.0 / rate_hz
    t_start = time.time()
    armed = False
    n_tick = 0

    while not stop_evt.is_set() and not rospy.is_shutdown():
        if args.duration > 0 and time.time() - t_start > args.duration:
            break

        loop_t0 = time.time()
        now = time.time()
        n_tick += 1

        if not armed and now - t_start >= args.arm_delay:
            armed = True
            print("[S4] 已解锁，开始跟随（v_max=%.2f m/s）" % args.vmax)

        with shared.lock:
            shared.odom.predict(now)
            st = shared.kf.step(now, None)
            age = now - shared.obs_time if shared.obs_time > 0 else 999.0
            reliable = age < args.stale_time
            state = shared.state

            if not armed:
                cmd = shared.ctrl.stop("启动保护")
            elif not st["initialized"]:
                cmd = shared.ctrl.stop("状态未初始化")
            elif state not in ("TRACK", "TRACK_LIDAR", "SEARCH_TRACK"):
                cmd = shared.ctrl.stop("未跟踪目标")
            elif shared.stop_reason:
                cmd = shared.ctrl.stop(shared.stop_reason)
            elif age >= args.stale_time:
                cmd = shared.ctrl.stop("观测超时")
            else:
                # 单帧漏检不再立刻停车：观测新鲜就直接跟，变旧就按预测滑行并降速，
                # 0.6 s 后才真正停。原厂靠 30 Hz 点云天然做到这点，我们用预测补位。
                c0 = 0.15
                if age <= c0:
                    coast = 1.0
                else:
                    coast = max(0.0, (args.stale_time - age) / (args.stale_time - c0))
                # 状态在世界系，控制律要的是车体系
                xb, yb = shared.odom.to_body(st["x"], st["y"])
                vxb, vyb = shared.odom.vec_to_body(st["vx"], st["vy"])
                # 雷达接管时观测噪声更大，降速留出减速余量；
                # 主动搜索时是外推的虚拟点，更要慢。
                if state == "SEARCH_TRACK":
                    vs = 0.5
                elif state == "TRACK_LIDAR":
                    vs = 0.7
                else:
                    vs = 1.0
                cmd = shared.ctrl.compute(now, xb, yb, vxb, vyb,
                                          reliable=True, coast=coast,
                                          v_scale=vs)
            shared.last_cmd = cmd
            # 里程计只用已发指令积分，模拟车的实际运动
            shared.odom.set_cmd(cmd["v"], cmd["delta"])

        # ---- 发布 ----
        if args.enable and pub is not None:
            msg = AckermannDriveStamped()
            msg.header.stamp = rospy.Time.now()
            msg.drive.speed = float(cmd["v"])
            msg.drive.steering_angle = float(cmd["delta"])
            pub.publish(msg)
        elif args.enable:
            pass  # pub 为空说明 import 失败，前面已提示

        if not args.quiet and n_tick % int(rate_hz) == 0:
            with shared.lock:
                ds = shared.kf.stats()
            line = ("[S4] %-5s #%-3s d=%5.2f v=%.2f δ=%+5.1f° age=%.2f %s | 拒%d 接受%d"
                    % (cmd["mode"], shared.locked_id, cmd["d"], cmd["v"],
                       np.degrees(cmd["delta"]), age, "OK" if reliable else "WEAK",
                       ds["n_gate_reject"], ds["n_update"]))
            if sys.stdout.isatty():
                sys.stdout.write("\r" + line + "   ")
                sys.stdout.flush()
            else:
                print(line)

        rest = period - (time.time() - loop_t0)
        if rest > 0:
            time.sleep(rest)


def perception_wrapper(args, pair, shared, stop_evt):
    """感知线程异常必须显式暴露：daemon 线程静默死掉会让车停在 STOP 却不报警。"""
    try:
        perception_loop(args, pair, shared, stop_evt)
    except Exception:
        import traceback
        traceback.print_exc()
        shared.stop_reason = "感知线程异常"
    finally:
        stop_evt.set()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.path.expanduser("~/follow/models/yolov8n.pt"))
    ap.add_argument("--duration", type=float, default=0.0, help="0 表示一直跑")
    ap.add_argument("--color-topic", default="/camera/color/image_raw")
    ap.add_argument("--depth-topic", default="/camera/aligned_depth_to_color/image_raw")
    ap.add_argument("--info-topic", default="/camera/color/camera_info")
    ap.add_argument("--cmd-topic", default="/ackermann_cmd")
    ap.add_argument("--conf", type=float, default=0.5)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--rate", type=float, default=30.0, help="控制频率 Hz")
    ap.add_argument("--vmax", type=float, default=0.45, help="线速度上限 m/s")
    ap.add_argument("--arm-delay", type=float, default=3.0, help="启动后强制零速的秒数")
    ap.add_argument("--stale-time", type=float, default=0.60,
                    help="观测超过该秒数未更新即判定不可信")
    ap.add_argument("--sigma-obs", type=float, default=0.08)
    ap.add_argument("--q-acc", type=float, default=0.6)
    ap.add_argument("--lower-ratio", type=float, default=0.60)
    ap.add_argument("--max-width", type=float, default=1.20)
    ap.add_argument("--min-points", type=int, default=200)
    ap.add_argument("--max-lost", type=int, default=20)
    ap.add_argument("--enable", action="store_true", help="真的发布速度指令（默认不发）")
    ap.add_argument("--visual", action="store_true", help="保存可视化视频（增加耗时）")
    ap.add_argument("--out", default="logs/s4_live.mp4")
    ap.add_argument("--csv", default="", help="逐帧关键数据 CSV 路径，空表示不记")
    ap.add_argument("--summary", default="",
                    help="退出时汇总 JSON 路径，空表示不记")
    ap.add_argument("--quiet", action="store_true", help="不打印实时状态行")
    args = ap.parse_args()

    rospy.init_node("wb_s4_follow", anonymous=True, disable_signals=True)

    print("=" * 62)
    if args.enable:
        print("模式：**会发布 /ackermann_cmd**，前 %.1f 秒强制零速" % args.arm_delay)
    else:
        print("模式：dry-run，只打印指令，不发布任何速度")
    print("v_max=%.2f m/s  d_des=1.20 m  控制 %.0f Hz  话题 %s"
          % (args.vmax, args.rate, args.cmd_topic))
    print("=" * 62)

    pub = None
    if args.enable:
        if AckermannDriveStamped is None:
            print("[S4] 缺少 ackermann_msgs，无法发布。已退回 dry-run。")
            args.enable = False
        else:
            pub = rospy.Publisher(args.cmd_topic, AckermannDriveStamped, queue_size=1)

    shared = Shared(args.sigma_obs, args.q_acc, args.vmax)

    pair = FramePair()
    rospy.Subscriber(args.color_topic, Image, pair.on_color, queue_size=1,
                     buff_size=2 ** 24)
    rospy.Subscriber(args.depth_topic, Image, pair.on_depth, queue_size=1,
                     buff_size=2 ** 24)
    rospy.Subscriber(args.info_topic, CameraInfo, pair.on_info, queue_size=1)

    # 雷达：只订阅，不阻塞；融合在感知线程里按需读取
    rospy.Subscriber("/scan", LaserScan, shared.lidar.on_scan, queue_size=1)

    stop_evt = threading.Event()
    th = threading.Thread(target=perception_wrapper, args=(args, pair, shared, stop_evt))
    th.daemon = True
    th.start()

    stats = None
    if args.csv:
        csv_path = args.csv if os.path.isabs(args.csv) else os.path.join(ROOT, args.csv)
        try:
            stats = Stats(csv_path)
            shared.stats = stats
            print("[S4] 逐帧数据 -> %s" % csv_path)
        except Exception as exc:
            print("[S4] 无法写 CSV %s: %s" % (csv_path, exc))

    writer = None
    if args.visual:
        out_path = args.out
        if not os.path.isabs(out_path):
            out_path = os.path.join(ROOT, out_path)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        writer = VideoSink(out_path, (PANEL_W * 2, PANEL_H * 2), fps=15.0)
        if not writer.ok:
            print("[S4] 无法创建视频 %s，跳过可视化" % out_path)
            writer = None
        else:
            print("[S4] 可视化 -> %s（彩色 | 深度 | 点云）" % out_path)
        shared.writer = writer

    try:
        control_loop(args, shared, pub, stop_evt)
    except KeyboardInterrupt:
        pass
    finally:
        stop_evt.set()
        # 退出必须发零速，且重复几次防止单帧丢失
        if args.enable and pub is not None:
            for _ in range(10):
                try:
                    msg = AckermannDriveStamped()
                    msg.header.stamp = rospy.Time.now()
                    msg.drive.speed = 0.0
                    msg.drive.steering_angle = 0.0
                    pub.publish(msg)
                except Exception:
                    break
                time.sleep(0.02)
            print("\n[S4] 已发送零速")
        shared.writer = None
        if writer is not None:
            writer.close()
            print("[S4] 视频已保存（丢弃帧 %d）" % writer.dropped)
        if stats is not None:
            summ = stats.summary()
            summ["video_dropped_frames"] = writer.dropped if writer is not None else 0
            summ["video"] = os.path.basename(args.out) if args.visual else ""
            summ["vmax_setting"] = args.vmax
            summ["enable"] = bool(args.enable)
            print("[S4] 汇总：" + json.dumps(summ, ensure_ascii=False,
                                             sort_keys=True))
            if args.summary:
                sp = args.summary
                if not os.path.isabs(sp):
                    sp = os.path.join(ROOT, sp)
                os.makedirs(os.path.dirname(sp), exist_ok=True)
                with open(sp, "w") as fh:
                    json.dump(summ, fh, ensure_ascii=False, indent=2, sort_keys=True)
                print("[S4] 汇总 JSON -> %s" % sp)
            stats.close()
        th.join(timeout=2.0)
        print("[S4] 停止")

    return 0


if __name__ == "__main__":
    sys.exit(main())
