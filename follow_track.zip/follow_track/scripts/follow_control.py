# -*- coding: utf-8 -*-
"""S4：跟随控制律。纯 Python，不依赖 ROS / numpy，可离线单测与仿真。

输入  车体系下的目标平面位置与速度（来自 S3 的 TrackFilter）
输出  阿克曼指令 (speed, steering_angle) + 模式与原因

坐标约定
    车体系：X 前、Y 左。目标在左前方 -> y > 0 -> 左转 -> steering > 0

为什么不用纯跟踪（pure pursuit）
    纯跟踪解的是"到达前方某点"的问题，需要构造虚拟目标点并把曲率写成
    y/Ld^2。跟随的本质是"保持距离 + 对准"，直接对距离与方位做误差反馈
    更可解释，也更容易做死区、滞回和降级。室内低速没有高速过弯的需求。

低速转向能力是这台车的硬约束
    阿克曼 ω = v·tan(δ)/L。v=0.1 m/s、δ=30° 时 ω 仅 0.183 rad/s，
    打满方向也要 5.5 s 才能转 90°。因此控制律里"转向优先"必然伴随
    降速，但降速又削弱转向 —— 必须显式设定速度下限，否则会卡死。
"""

import math

STEER_LEFT = 1
STEER_RIGHT = -1


class FollowController(object):
    """距离 + 方位双环，输出阿克曼指令。

    参数（默认值针对 scorpio：轴距 0.315 m，最大前轮转角 30°）
    """

    def __init__(self,
                 wheelbase=0.315,
                 max_steer=math.radians(35.0),
                 d_des=1.20,
                 d_dead=0.08,
                 d_hyst=0.04,
                 v_max=0.45,
                 v_rev=0.15,
                 v_min=0.05,
                 d_min_safe=0.55,
                 k_d=1.20,
                 near_zone=1.10,
                 near_speed=0.35,
                 k_theta=2.00,
                 theta_dead=math.radians(3.0),
                 theta_slow=math.radians(25.0),
                 v_slow_factor=0.70,
                 turn_min_speed=0.25,
                 max_accel=1.50,
                 max_steer_rate=3.00,
                 max_omega=1.20,
                 rear_zone=math.radians(150.0),
                 stale_time=0.60):
        self.wheelbase = float(wheelbase)
        self.max_steer = float(max_steer)
        self.d_des = float(d_des)
        self.d_dead = float(d_dead)
        self.d_hyst = float(d_hyst)
        self.v_max = float(v_max)
        self.v_rev = float(v_rev)
        self.v_min = float(v_min)
        self.d_min_safe = float(d_min_safe)
        self.k_d = float(k_d)
        self.near_zone = float(near_zone)
        self.near_speed = float(near_speed)
        self.k_theta = float(k_theta)
        self.theta_dead = float(theta_dead)
        self.theta_slow = float(theta_slow)
        self.v_slow_factor = float(v_slow_factor)
        self.turn_min_speed = float(turn_min_speed)
        self.max_accel = float(max_accel)
        self.max_steer_rate = float(max_steer_rate)
        self.max_omega = float(max_omega)
        self.rear_zone = float(rear_zone)
        self.stale_time = float(stale_time)

        # 上一次输出，用于变化率限制与滞回
        self.last_v = 0.0
        self.last_delta = 0.0
        self.last_t = None
        self.moving = False      # 滞回状态：是否处于"正在跟随"

    # ------------------------------------------------------------------
    def reset(self):
        self.last_v = 0.0
        self.last_delta = 0.0
        self.last_t = None
        self.moving = False

    def stop(self, reason="stop"):
        """立即输出零速。用于 SEARCH / ESTOP。"""
        self.last_v = 0.0
        self.last_delta = 0.0
        self.moving = False
        cmd = self._pack(0.0, 0.0, "STOP", reason, True)
        return cmd

    # ------------------------------------------------------------------
    def compute(self, t, x, y, vx=0.0, vy=0.0, reliable=True, coast=1.0,
                v_scale=1.0):
        """t 为观测时间戳（秒）。x,y 为目标在车体系下的位置。

        coast 0..1：本帧没有新观测、靠卡尔曼预测滑行时的速度衰减系数。
            1.0 表示观测新鲜，正常跟随；随观测变旧线性衰减到 0。
            目的与原厂一致——不让单帧漏检把车瞬间打死，避免走走停停。

        返回 dict：
            v        线速度指令 m/s（非负，车不后退）
            delta    前轮转角 rad，左正右负
            omega    等效偏航角速度 rad/s（诊断用）
            mode     TRACK / SLOW / HOLD / STOP
            reason   一句话说明
            reliable 输入是否可信
            d, bearing  当前距离与方位角（诊断用）
        """
        dt = 0.0 if self.last_t is None else max(0.0, t - self.last_t)
        self.last_t = t

        d = math.hypot(x, y)
        if d < 1e-6:
            return self.stop("目标与车重合")

        bearing = math.atan2(y, x)

        # ---- 安全降级：输入不可信就不动 ----
        if not reliable:
            return self._hold("估计不可信", d, bearing, dt)

        # ---- 目标在车后方：阿克曼无法原地掉头，停车等它回到前方 ----
        if abs(bearing) > self.rear_zone:
            return self._hold("目标在后方", d, bearing, dt)

        e_d = d - self.d_des                # >0 太远，<0 太近
        e_theta = bearing

        # ---- 速度环 ----
        v_ff = vx * math.cos(bearing) + vy * math.sin(bearing)   # 人的径向速度前馈

        v = self.k_d * e_d + v_ff * coast

        # 方位误差大时降速：把速度预算让给转向
        need_turn = abs(e_theta) > self.theta_slow
        if need_turn:
            v *= self.v_slow_factor
            # 转向最低速度：阿克曼车必须保持前进速度才能转向，
            # 距离已到位时 v 会趋近 0，但方位没对准仍需转，此时
            # 不能停，否则永远转不过去。保底一个最小前进速度。
            if v < self.turn_min_speed:
                v = self.turn_min_speed

        # ---- 死区 + 滞回 ----
        # 只有距离和方位都到位才算"已到位"。方位误差大时必须继续转，
        # 不能因为距离到位就判停。
        inside = abs(e_d) < self.d_dead and abs(e_theta) < self.theta_dead
        if inside:
            self.moving = False
            return self._hold("已到位", d, bearing, dt)
        # 已停住时，需要超出死区 + 滞回才重新起步
        if not self.moving:
            if abs(e_d) < self.d_dead + self.d_hyst and abs(e_theta) < 2 * self.theta_dead:
                return self._hold("死区内", d, bearing, dt)

        # 极近距离才真正停车：低于这个距离后退也不安全
        if d < self.d_min_safe:
            self.moving = False
            return self._hold("近距保护", d, bearing, dt)

        # ---- 太近就后退，而不是停车 ----
        # 原厂 x_linear=(depth-goal)*scale 本来就是双向的，人走近时车会退。
        # 之前这里直接 HOLD，既造成"不后退"，也是走走停停的主要来源之一。
        if e_d < 0.0:
            v = max(-self.v_rev, min(0.0, v))
        else:
            # 接近段限速：k_d=0.9 时 d>1.70 就饱和到 v_max，真正的减速区只有
            # 0.38 m。0.45 m/s 在 max_accel=1.5 下刹停要 0.07 m，加上检测延迟
            # 余量仍然不多。进入 near_zone 后把上限压到 near_speed。
            cap = min(self.v_max, self.near_speed) if d < self.near_zone else self.v_max
            # 转弯保底：需要转时，即便距离很近，也保留转向所需的最低速度，
            # 否则 near_zone 会把速度压到 0，阿克曼车就转不动了。
            if need_turn:
                cap = max(cap, self.turn_min_speed)
            v = max(0.0, min(cap, v))

        # 滑行衰减：观测越旧越不敢靠预测猛冲，允许低于 v_min 甚至归零
        cf = max(0.0, min(1.0, coast))
        if cf < 1.0:
            v *= cf

        # 观测质量降速：雷达接管的观测噪声比深度大，留出减速余量
        vs = max(0.0, min(1.0, float(v_scale)))
        v *= vs

        self.moving = True

        # ---- 转向环 ----
        omega = self.k_theta * e_theta
        omega = max(-self.max_omega, min(self.max_omega, omega))

        # 阿克曼逆解。倒车要反打：v<0 时直接 atan2 会得到钝角被限幅，
        # 实际偏航方向会反，所以按 |v| 求解再取反。
        if v >= 0.0:
            delta = math.atan2(omega * self.wheelbase, max(1e-6, v))
        else:
            delta = -math.atan2(omega * self.wheelbase, max(1e-6, -v))

        # 转角限幅；限幅后真实可达的 omega 由车速与轴距决定
        delta = max(-self.max_steer, min(self.max_steer, delta))
        omega = v * math.tan(delta) / self.wheelbase

        # ---- 变化率限制，抑制抽搐 ----
        # 必须对 dt 封顶：真机偶发 0.2 s 的间隔，按 dt 线性放大等于不限幅
        dv, dd = self._rate_limit(dt)
        v = max(self.last_v - dv, min(self.last_v + dv, v))
        delta = max(self.last_delta - dd, min(self.last_delta + dd, delta))
        omega = v * math.tan(delta) / self.wheelbase

        if v < -1e-6:
            mode = "REV"
        elif abs(e_theta) > self.theta_slow:
            mode = "SLOW"
        else:
            mode = "TRACK"
        return self._pack(v, delta, mode,
                          "d=%+.2f eθ=%+.0f°" % (e_d, math.degrees(e_theta)),
                          True, d, bearing, omega)

    # ------------------------------------------------------------------
    def _rate_limit(self, dt):
        """单步允许的速度与转角变化量。

        dt 封顶 0.10 s：控制周期 30 Hz 时按实际间隔缩放，
        但长时间断流后不能一次跳变整段行程。
        """
        dtt = min(max(dt, 0.0), 0.10)
        dv = self.max_accel * dtt
        dd = self.max_steer_rate * dtt
        return dv, dd

    def _hold(self, reason, d, bearing, dt):
        """保持零速，转向回正（按变化率缓慢回正，不硬打）。"""
        _, dd = self._rate_limit(dt)
        delta = self.last_delta
        if abs(delta) <= dd:
            delta = 0.0
        else:
            delta -= math.copysign(dd, delta)
        self.last_v = 0.0
        self.last_delta = delta
        return self._pack(0.0, delta, "HOLD", reason, True, d, bearing, 0.0)

    def _pack(self, v, delta, mode, reason, reliable, d=0.0, bearing=0.0, omega=0.0):
        self.last_v = v
        self.last_delta = delta
        return {
            "v": float(v),
            "delta": float(delta),
            "omega": float(omega),
            "mode": mode,
            "reason": reason,
            "reliable": bool(reliable),
            "d": float(d),
            "bearing": float(bearing),
        }


def omega_limit(v, wheelbase, max_steer):
    """给定车速下阿克曼可达的最大偏航角速度。"""
    return abs(v) * math.tan(max_steer) / wheelbase
