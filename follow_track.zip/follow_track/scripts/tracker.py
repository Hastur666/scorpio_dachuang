# -*- coding: utf-8 -*-
"""
ByteTrack 封装 + 颜色 ReID 锁定策略。

ByteTrack 侧不做任何源码修改，两处兼容问题在本层以运行时方式解决：
  1. np.float 别名 —— 由 compat.py 在导入前补齐
  2. args.mot20 缺失 —— 由 TrackerArgs 显式提供

上游版本：d1bf0191adff59bc8fcfeaa0b33d3d1642552a99 (2022-12-11)

颜色 ReID
    ByteTrack 只用 IoU + 卡尔曼做关联，没有外观特征，目标被遮挡后
    重捕会得到新的 track_id。这里用上半身（头肩区域）的 HSV 颜色直方图
    作为外观指纹：
        锁定 -> 提取指纹
        目标丢失后重捕 -> 用巴氏距离匹配指纹，找回同一个人
    不依赖 track_id，ID 变了只要颜色匹配就续跟。
"""

import numpy as np
import cv2


class TrackerArgs(object):
    """替代 ByteTrack 的 argparse.Namespace，补齐其读取的全部字段。"""

    def __init__(self, track_thresh=0.5, track_buffer=30,
                 match_thresh=0.8, mot20=False):
        self.track_thresh = float(track_thresh)
        self.track_buffer = int(track_buffer)
        self.match_thresh = float(match_thresh)
        self.mot20 = bool(mot20)


class PersonTracker(object):
    """ByteTrack 关联器。输出 (track_id, tlbr, score)。"""

    def __init__(self, track_thresh=0.5, track_buffer=30,
                 match_thresh=0.8, mot20=False, frame_rate=30):
        from yolox.tracker.byte_tracker import BYTETracker

        self.args = TrackerArgs(track_thresh, track_buffer,
                                match_thresh, mot20)
        self.tracker = BYTETracker(self.args, frame_rate=int(frame_rate))

    def update(self, dets, frame_shape):
        """
        参数
            dets: (N,5) [x1,y1,x2,y2,score]，可为空数组
            frame_shape: (H, W, ...)

        返回
            list of (track_id:int, tlbr:np.ndarray(4), score:float)
            按置信度降序
        """
        h, w = int(frame_shape[0]), int(frame_shape[1])

        if dets is None or len(dets) == 0:
            dets = np.empty((0, 5), dtype=np.float64)
        else:
            dets = np.asarray(dets, dtype=np.float64)

        online = self.tracker.update(dets, [h, w], [h, w])

        out = []
        for t in online:
            if t is None:
                continue
            tlbr = np.asarray(t.tlbr, dtype=np.float64)[:4]
            tid = int(t.track_id)
            score = float(getattr(t, "score", 0.0))
            out.append((tid, tlbr, score))

        out.sort(key=lambda x: -x[2])
        return out


def _color_fingerprint(image, tlbr):
    """提取 bbox 的 HSV 颜色直方图指纹。

    取上半身（头肩，占 0~45%）和下半身（腿部，占 45~100%）两段分别算
    直方图再拼接，信息量比单取上半身更大，重捕时更鲁棒。上半身衣服和
    下半身裤子颜色都是相对稳定的外观特征。HSV 只取 H、S 两通道，忽略 V
    （亮度），对光照变化更稳。
    """
    x1, y1, x2, y2 = [int(round(v)) for v in tlbr[:4]]
    H, W = image.shape[:2]
    x1 = max(0, x1); y1 = max(0, y1)
    x2 = min(W, x2); y2 = min(H, y2)
    if x2 <= x1 or y2 <= y1:
        return None

    h = y2 - y1
    # 上半身 0~45%，下半身 45~100%
    y_mid = y1 + int(h * 0.45)
    if y_mid <= y1:
        y_mid = y1 + 1
    rois = [image[y1:y_mid, x1:x2], image[y_mid:y2, x1:x2]]

    hists = []
    for roi in rois:
        if roi.size == 0:
            hists.append(np.zeros(32 * 32, dtype=np.float32))
            continue
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [32, 32],
                            [0, 180, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        hists.append(hist)

    return np.concatenate(hists)


def _hist_dist(h1, h2):
    """巴氏距离，0 = 完全相同，1 = 完全不同。"""
    if h1 is None or h2 is None:
        return 1.0
    return float(cv2.compareHist(h1, h2, cv2.HISTCMP_BHATTACHARYYA))


class TargetSelector(object):
    """
    自动锁定 + 颜色 ReID。

    流程
        - 未锁定：选面积最大的候选，连续确认 lock_confirm 帧后锁定，
          并提取颜色指纹。
        - 已锁定：优先用 track_id 找；找不到（ByteTrack 换号或目标短暂
          出画）就用颜色指纹在候选里找回同一个人。
        - 彻底丢失：fingerprint 保留一段时间，供重捕时匹配；超时或
          freeze 后不再匹配。

    安全约束沿用 S2 版：
        - 框不在画面内 -> 不计有效观测
        - 解锁后冷却 + 连续确认才重锁
        - 锁定需满足最小面积
    """

    def __init__(self, max_lost=15, lock_confirm=3, cooldown=15,
                 min_area_ratio=0.01, in_frame_ratio=0.60,
                 image_size=(480, 640),
                 reid_thresh=0.45, reid_keep_frames=90):
        self.max_lost = int(max_lost)
        self.lock_confirm = int(lock_confirm)
        self.cooldown_cfg = int(cooldown)
        self.min_area_ratio = float(min_area_ratio)
        self.in_frame_ratio = float(in_frame_ratio)
        self.h_img, self.w_img = int(image_size[0]), int(image_size[1])
        self.reid_thresh = float(reid_thresh)
        self.reid_keep_frames = int(reid_keep_frames)

        self.locked_id = None
        self.fingerprints = []      # 目标的历史颜色指纹（保留多个，更鲁棒）
        self.lost_frames = 0
        self.cooldown = 0
        self.cand_id = None
        self.cand_frames = 0

        self.lock_events = 0
        self.unlock_events = 0
        self.degraded_frames = 0
        self.frozen = False

    # ---------- 指纹维护 ----------

    def _remember_fingerprint(self, image, tlbr):
        """提取并记录一帧指纹，保留最近 N 个。"""
        fp = _color_fingerprint(image, tlbr)
        if fp is None:
            return
        self.fingerprints.append(fp)
        if len(self.fingerprints) > 8:
            del self.fingerprints[0]

    def _match_fingerprint(self, image, tlbr):
        """候选框与历史指纹的最小巴氏距离。无指纹返回 1.0。"""
        if not self.fingerprints:
            return 1.0
        fp = _color_fingerprint(image, tlbr)
        if fp is None:
            return 1.0
        return min(_hist_dist(f, fp) for f in self.fingerprints)

    # ---------- 几何判据 ----------

    @staticmethod
    def _area(tlbr):
        return max(0.0, float(tlbr[2] - tlbr[0])) * \
               max(0.0, float(tlbr[3] - tlbr[1]))

    def _frame_overlap(self, tlbr):
        a = self._area(tlbr)
        if a <= 1e-6:
            return 0.0
        x1 = max(0.0, float(tlbr[0])); y1 = max(0.0, float(tlbr[1]))
        x2 = min(float(self.w_img), float(tlbr[2]))
        y2 = min(float(self.h_img), float(tlbr[3]))
        if x2 <= x1 or y2 <= y1:
            return 0.0
        return ((x2 - x1) * (y2 - y1)) / a

    def _in_frame(self, tlbr):
        return self._frame_overlap(tlbr) >= self.in_frame_ratio

    # ---------- 主更新 ----------

    def update(self, tracks, has_depth_obs=True, frame_shape=None, image=None):
        """
        参数
            tracks: list of (tid, tlbr, score)
            has_depth_obs: 本帧目标是否有有效深度观测
            frame_shape: (H, W) 或 (H, W, 3)
            image: BGR 图像，用于提取/匹配颜色指纹。None 时跳过 ReID。

        返回
            (target, just_locked)
        """
        if frame_shape is not None:
            self.h_img = int(frame_shape[0])
            self.w_img = int(frame_shape[1])

        if self.cooldown > 0:
            self.cooldown -= 1

        if self.locked_id is None:
            return self._try_lock(tracks, image)

        # ---- 已锁定 ----
        cur = None
        for t in tracks:
            if t[0] == self.locked_id:
                cur = t
                break

        # track_id 直接命中
        valid = (cur is not None) and self._in_frame(cur[1]) and has_depth_obs
        if valid:
            self.lost_frames = 0
            if image is not None:
                self._remember_fingerprint(image, cur[1])
            return cur, False

        # track_id 没命中：用颜色指纹在候选里找回（ReID）
        if self.fingerprints and image is not None:
            cands = [t for t in tracks
                     if self._area(t[1]) >= self.min_area_ratio
                     * self.w_img * self.h_img and self._in_frame(t[1])]
            best = None
            best_d = self.reid_thresh
            for t in cands:
                d = self._match_fingerprint(image, t[1])
                if d < best_d:
                    best_d = d
                    best = t
            if best is not None:
                # 颜色匹配，判为同一人，更新锁定 ID 并记录指纹
                self.locked_id = best[0]
                self.lost_frames = 0
                self._remember_fingerprint(image, best[1])
                return best, False

        # 无效观测：容忍 max_lost 帧
        self.lost_frames += 1
        self.degraded_frames += 1
        if self.lost_frames > self.max_lost:
            self._unlock(keep_fingerprint=True)
        return None, False

    def _unlock(self, keep_fingerprint=False):
        self.locked_id = None
        self.lost_frames = 0
        self.cand_id = None
        self.cand_frames = 0
        self.cooldown = self.cooldown_cfg
        self.unlock_events += 1
        if not keep_fingerprint:
            self.fingerprints = []

    def freeze(self):
        """终止跟踪：解除锁定且不再自动锁定任何新目标。"""
        self._unlock(keep_fingerprint=False)
        self.frozen = True

    def _try_lock(self, tracks, image):
        if self.frozen:
            self.cand_id = None
            self.cand_frames = 0
            return None, False
        if not tracks or self.cooldown > 0:
            self.cand_id = None
            self.cand_frames = 0
            return None, False

        min_area = self.min_area_ratio * self.w_img * self.h_img
        cands = [t for t in tracks
                 if self._area(t[1]) >= min_area and self._in_frame(t[1])]
        if not cands:
            self.cand_id = None
            self.cand_frames = 0
            return None, False

        # 若有历史指纹，优先颜色匹配；否则选面积最大
        best = None
        matched_by_reid = False
        if self.fingerprints and image is not None:
            best_d = self.reid_thresh
            for t in cands:
                d = self._match_fingerprint(image, t[1])
                if d < best_d:
                    best_d = d
                    best = t
                    matched_by_reid = True
        if best is None:
            best = max(cands, key=lambda t: self._area(t[1]))

        if best[0] == self.cand_id:
            self.cand_frames += 1
        else:
            self.cand_id = best[0]
            self.cand_frames = 1

        # 有指纹匹配到同一个人时，1 帧即可重锁（人回来了，快速接上）；
        # 没有指纹、纯按面积选的，才需要连续确认防抖。
        need_confirm = 1 if matched_by_reid else self.lock_confirm
        if self.cand_frames < need_confirm:
            return None, False

        self.locked_id = best[0]
        self.lost_frames = 0
        self.cand_id = None
        self.cand_frames = 0
        self.lock_events += 1
        if image is not None:
            self._remember_fingerprint(image, best[1])
        return best, True

    @property
    def is_locked(self):
        return self.locked_id is not None
