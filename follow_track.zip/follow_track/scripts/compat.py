# -*- coding: utf-8 -*-
"""
numpy / ByteTrack 兼容层。

必须在导入 ultralytics 与 ByteTrack 之前 import 本模块。

背景：
  - numpy 1.24 移除了 np.float / np.int / np.bool 等别名，
    而 ByteTrack (commit d1bf019, 2022-12-11) 仍在用 np.float，
    首次产生检测框时会抛 AttributeError。
  - 本模块只在运行时给 numpy 补别名，不修改 vendor 下的任何文件。
"""

import numpy as np

_ALIASES = {
    "float": np.float64,
    "int": int,
    "bool": bool,
    "object": object,
    "str": str,
}

for _name, _target in _ALIASES.items():
    # 用 np.__dict__ 直接判断，避免触发 numpy 的 __getattr__ 产生 FutureWarning
    if _name not in np.__dict__:
        setattr(np, _name, _target)

NUMPY_PATCHED = True


def _patch_cv2_copyMakeBorder():
    """cv2 4.13 与 ultralytics 8.4.37 的 letterbox 存在类型冲突：
    cv2.copyMakeBorder 的 top/bottom/left/right 收到 float 时抛
    TypeError: integer argument expected, got float。
    这里给 copyMakeBorder 包一层，把 4 个边距参数强制转 int。
    """
    import cv2
    if getattr(cv2, "_WB_BORDER_PATCHED", False):
        return
    _orig = cv2.copyMakeBorder

    def _patched(src, top, bottom, left, right, *args, **kwargs):
        return _orig(src, int(top), int(bottom), int(left), int(right),
                     *args, **kwargs)

    cv2.copyMakeBorder = _patched
    cv2._WB_BORDER_PATCHED = True


_patch_cv2_copyMakeBorder()
CV2_PATCHED = True
