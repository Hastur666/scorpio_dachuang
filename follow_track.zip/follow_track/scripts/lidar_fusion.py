# -*- coding: utf-8 -*-
"""
lidar_fusion.py —— 雷达簇检测 + 位置门匹配 + 目标航迹。

核心：雷达不判断"是不是人腿"，只回答"给的那个位置附近，有没有一个
连续存在的簇"。身份由视觉给（深度定位给出车体系 x,y 作为锚点），
雷达负责在视觉丢失期间接续这个锚点。

三个接口
    match_xy(xb, yb, gate)   按车体系位置匹配最近簇（位置门，不是角度门）
    track_ok()               本帧航迹是否可用（连续命中）
    snapshot()               供可视化

航迹判定
    - 相邻帧匹配到的簇位移必须 < MAX_JUMP，否则判为跳变、拒绝
    - 连续 MISS_TOL 帧未命中才算航迹断开（容忍单帧漏检）
    - 视觉丢失时靠这条航迹接管，4 秒无视觉确认由上层放弃

坐标：车体系 X 前 Y 左。雷达极坐标 (r, θ) 中 θ 以车头为 0 左正，
故 Xb=r·cosθ、Yb=r·sinθ。
"""

import math
import threading


RANGE_MIN = 0.35
# 4.5 m：角度分辨率 0.396° 下，一条 0.12 m 宽的腿在 4.5 m 处约 3~4 个点，
# 是还能成簇的边界。再远点太稀，簇中心和宽度都不可信。
RANGE_MAX = 4.5
GROUP_DIST = 0.25
# 腿簇宽度上限。保持宽松（0.6），确保能锁到人（人腿并拢/转弯/遮挡会拉宽）。
# 排杂物不靠卡宽度，而靠占用栅格做动静检测（见 motion_grid）。
MAX_WIDTH = 0.6
MIN_POINTS = 2
ANGLE_WIN = 20.0     # 兼容旧接口，角度窗匹配
MAX_JUMP = 0.60      # 相邻帧簇位移上限，超过判为跳变
MISS_TOL = 8         # 连续未命中多少帧才算航迹断开（约 0.5s @15Hz）
HIST_LEN = 5         # 轨迹历史保留帧数，用于跟丢后的方向外推

# laser_frame 相对 base_footprint 的 x 平移。静态 TF 实测 (-0.073, 0, 0.27)，
# 俯仰 -0.0873 rad 只影响 z，水平投影缩 0.4% 可忽略，故只补 x。
# 不补这一项，雷达坐标会比深度坐标恒定偏 7.3cm，加上相机侧 0.160m，
# 两者相差 23.3cm，会把位置门预算吃掉一大半。
LASER_X_OFFSET = -0.073

# 距离偏置：雷达测的是腿的前沿，深度测的是身体表面，两者有系统差。
# 实测约 0.12~0.18 m（身体半径 + 腿到身体的距离）。雷达距离偏小，
# 直接喂给卡尔曼会和深度观测冲突，导致位置跳变、卡顿。这里把雷达
# 簇中心沿径向往外推这个量，让两种观测的"目标位置"标准一致。
LIDAR_DIST_BIAS = 0.15


class LidarFusion(object):
    """订阅 /scan，按位置门匹配簇，维护一条目标航迹。"""

    def __init__(self, angle_win=ANGLE_WIN):
        self.angle_win = float(angle_win)
        self.lock = threading.Lock()
        self._scan = None   # (angle_deg_list, range_list)

        # 航迹状态
        self.track_xy = None      # 上一帧匹配到的簇中心 (xb, yb)
        self.history = []         # 最近若干帧的轨迹点，用于方向外推
        self.hits = 0             # 累计命中
        self.misses = 0           # 连续未命中
        self.warm = False         # 航迹是否可用（连续命中过且未断）

        # 动静检测：累积几秒占用栅格，标记静止的桌腿/墙柱
        from motion_grid import MotionGrid
        self.grid = MotionGrid()

    def reset_track(self):
        self.track_xy = None
        self.history = []
        self.hits = 0
        self.misses = 0
        self.warm = False

    def on_scan(self, msg):
        """LaserScan 回调，只存原始点，聚类留到 detect 时做。"""
        angles = []
        ranges = []
        n = len(msg.ranges)
        a_min = msg.angle_min
        a_inc = msg.angle_increment
        for i, r in enumerate(msg.ranges):
            if RANGE_MIN < r < RANGE_MAX:
                angles.append(math.degrees(a_min + i * a_inc))
                ranges.append(r)
        with self.lock:
            self._scan = (angles, ranges)

    def _cluster(self, angles, ranges):
        """1D 聚类 + 腿簇筛选，返回 [(cx, cy, r, ang_deg, width, npts)]。"""
        if not angles:
            return []
        pts = sorted(zip(angles, ranges), key=lambda x: x[0])
        clusters = []
        cur = [pts[0]]
        for i in range(1, len(pts)):
            x1 = pts[i - 1][1] * math.cos(math.radians(pts[i - 1][0]))
            y1 = pts[i - 1][1] * math.sin(math.radians(pts[i - 1][0]))
            x2 = pts[i][1] * math.cos(math.radians(pts[i][0]))
            y2 = pts[i][1] * math.sin(math.radians(pts[i][0]))
            if math.hypot(x1 - x2, y1 - y2) < GROUP_DIST:
                cur.append(pts[i])
            else:
                clusters.append(cur)
                cur = [pts[i]]
        clusters.append(cur)

        out = []
        for c in clusters:
            if len(c) < MIN_POINTS:
                continue
            x0 = c[0][1] * math.cos(math.radians(c[0][0]))
            y0 = c[0][1] * math.sin(math.radians(c[0][0]))
            x1 = c[-1][1] * math.cos(math.radians(c[-1][0]))
            y1 = c[-1][1] * math.sin(math.radians(c[-1][0]))
            w = math.hypot(x0 - x1, y0 - y1)
            if w > MAX_WIDTH:
                continue
            cx = sum(p[1] * math.cos(math.radians(p[0])) for p in c) / len(c)
            cy = sum(p[1] * math.sin(math.radians(p[0])) for p in c) / len(c)
            # laser_frame -> base_footprint：只补 x 平移
            cx += LASER_X_OFFSET
            r = math.hypot(cx, cy)
            ang = math.degrees(math.atan2(cy, cx))
            out.append((cx, cy, r, ang, w, len(c)))
        return out

    def match_xy(self, xb, yb, gate=0.40, use_motion_filter=False):
        """按车体系位置匹配最近的簇，并维护航迹。

        参数
            xb, yb: 期望位置（车体系，米）。视觉有效时传深度定位结果，
                    视觉丢失时传卡尔曼预测位置。
            gate  : 位置门半径（米）
            use_motion_filter: 是否用动静检测排除静态物。视觉在线时
                    锚点足够准，不需要过滤（False）；视觉丢失、雷达要
                    独立从一堆簇里挑人时才启用（True）。

        返回
            dict  {"Xb","Yb","r","ang","n","width"} 或 None
            None 表示这一帧没匹配到（航迹 misses+1）
        """
        with self.lock:
            if self._scan is None:
                return self._miss()
            angles, ranges = self._scan

        clusters = self._cluster(angles, ranges)
        if not clusters:
            return self._miss()

        # 更新动静栅格：把所有扫描点喂进去，累积几秒后静止物会被标记。
        # 只在需要过滤时才真正用栅格排除（见下），但更新始终做，保持
        # 栅格热状态，避免"要用时还没积累够"。
        raw_pts = [(r * math.cos(math.radians(a)) + LASER_X_OFFSET,
                    r * math.sin(math.radians(a)))
                   for a, r in zip(angles, ranges)]
        self.grid.update(raw_pts)

        # 门中心的选择是这套方案的关键：
        #   已有航迹 -> 用上一帧匹配到的位置，航迹自己往前走。
        #   尚无航迹 -> 用外部给的锚点（视觉预热时是深度定位结果）。
        # 一旦有航迹就不再依赖外部预测，因此完全不碰里程计，
        # 转弯时不会因为 odom 漂移把门开到错误的位置。
        if self.track_xy is not None:
            gx, gy = self.track_xy
        else:
            gx, gy = xb, yb

        best = None
        best_d = gate
        for (cx, cy, r, ang, w, n) in clusters:
            # 视觉丢失、雷达独立找目标时，排除静止物（桌腿/墙柱）。
            # 视觉在线时不过滤：锚点足够准，且过滤会误杀站定的人。
            if use_motion_filter and self.grid.is_static(cx, cy):
                continue
            d = math.hypot(cx - gx, cy - gy)
            if d < best_d:
                best_d = d
                best = (cx, cy, r, ang, w, n)

        if best is None:
            return self._miss()

        cx, cy, r, ang, w, n = best

        # 位置跳变门：单帧不可能移动超过 MAX_JUMP
        if self.track_xy is not None:
            jump = math.hypot(cx - self.track_xy[0], cy - self.track_xy[1])
            if jump > MAX_JUMP:
                return self._miss()

        # 距离偏置：把簇中心沿径向推到"身体表面"位置，与深度观测对齐。
        # 只改返回给上层的位置，不改航迹存储（航迹要保持几何连续性）。
        if r > 1e-6:
            scale = (r + LIDAR_DIST_BIAS) / r
            ox = cx * scale
            oy = cy * scale
        else:
            ox, oy = cx, cy

        self.track_xy = (cx, cy)
        self.history.append((cx, cy))
        if len(self.history) > HIST_LEN:
            del self.history[0]
        self.hits += 1
        self.misses = 0
        self.warm = True
        return {"Xb": ox, "Yb": oy, "r": r + LIDAR_DIST_BIAS,
                "ang": ang, "n": n, "width": w}

    def _miss(self):
        self.misses += 1
        if self.misses > MISS_TOL:
            self.warm = False
            self.track_xy = None
        return None

    def drop_keep_history(self):
        """停跟随但保留轨迹历史。

        用于视觉佐证判定"锁错了"时：清掉当前锁定，但保留 history，
        让上层还能沿最后轨迹方向外推搜索。若用 reset_track() 连 history
        一起清，extrapolate() 就永远返回 None，搜索直接失效。
        """
        self.warm = False
        self.track_xy = None
        self.misses = 0

    def extrapolate(self, ahead=1.5):
        """按最近轨迹的外推点，用于跟丢后主动搜索。

        用最近两帧的位移方向外推 ahead 米；历史不足或位移过小则返回 None。
        返回车体系 (x, y)。
        """
        if len(self.history) < 2:
            return None
        x0, y0 = self.history[-2]
        x1, y1 = self.history[-1]
        dx, dy = x1 - x0, y1 - y0
        norm = math.hypot(dx, dy)
        if norm < 0.02:          # 几乎没动，方向不可信
            return None
        return (x1 + dx / norm * ahead, y1 + dy / norm * ahead)

    def track_ok(self):
        """航迹是否可用于接管。"""
        return bool(self.warm and self.track_xy is not None)

    def detect(self, cam_angle):
        """
        参数 cam_angle：相机角度（度），None 表示相机无目标。
        返回 dict 或 None：
            {"Xb":..., "Yb":..., "r":..., "ang":..., "n":..., "width":...}
        车体系 X 前 Y 左。雷达极坐标 (r, ang) 中 ang 以车头为 0 左正，
        与车体系 (X前 Y左) 一致，故 Xb=r*cos, Yb=r*sin。
        """
        if cam_angle is None:
            return None
        with self.lock:
            if self._scan is None:
                return None
            angles, ranges = self._scan

        clusters = self._cluster(angles, ranges)
        best = None
        for (cx, cy, r, ang, w, n) in clusters:
            d = abs(ang - cam_angle)
            # 处理 ±180° 环绕
            if d > 180.0:
                d = 360.0 - d
            if d < self.angle_win:
                if best is None or r < best[1]:
                    best = (cx, cy, r, ang, w, n)

        if best is None:
            return None
        cx, cy, r, ang, w, n = best
        return {"Xb": cx, "Yb": cy, "r": r, "ang": ang, "n": n, "width": w}

    def snapshot(self):
        """供可视化：返回 (原始点 (x,y) 列表, 腿簇列表 [(cx,cy,r,ang,w,n)])。"""
        with self.lock:
            if self._scan is None:
                return [], []
            angles, ranges = self._scan
        pts = [(r * math.cos(math.radians(a)) + LASER_X_OFFSET,
                r * math.sin(math.radians(a)))
               for a, r in zip(angles, ranges)]
        clusters = self._cluster(angles, ranges)
        return pts, clusters
