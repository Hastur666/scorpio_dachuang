# -*- coding: utf-8 -*-
"""
bbox + 对齐深度图 -> 目标 3D 位置（车体系）。

七步流水线（对应技术设计 §4）：

  1. 只取 bbox 下部 lower_ratio：腿部与躯干下缘深度最实，避开头发边缘
     与背景混合点
  2. 有效深度筛选：剔除 0 值（无回波）与超出量程的像素
  3. 深度直方图（bin=2 cm）取最高峰：人体是连续深度面，点数必然占优
  4. 只保留峰值 +-peak_tol 内的点 —— 这一步把"框内所有东西"收敛为
     "框内那个深度面上的东西"，墙面、地面、身后物体在此被剔除
  5. 反投影到相机系 (X 右, Y 下, Z 前)
  6. 人体尺寸合理性校验：点数、宽度、深度离散度
  7. 取中位数（不用均值）：抗边缘混合点与姿态摆动

设计取舍：
  - 用 aligned_depth_to_color 反投影，不用 organized 点云。
    点云 640x480 每帧约 9.8 MB、30 Hz 即 295 MB/s 内存流量，
    而本模块只需框内数千点，反投影是微秒级。
  - 取中位数而非均值：边缘混合点（深度落在前景与背景中间）会把均值
    拉偏，中位数对其免疫。
"""

import numpy as np


class LocateResult(object):
    """单帧定位结果。invalid 为真时其余字段无意义。"""

    __slots__ = ("valid", "reason", "X", "Y", "Z", "u", "v",
                 "n_points", "width_m", "depth_std", "peak_depth")

    def __init__(self, valid=False, reason="", **kw):
        self.valid = bool(valid)
        self.reason = reason
        self.X = float(kw.get("X", 0.0))
        self.Y = float(kw.get("Y", 0.0))
        self.Z = float(kw.get("Z", 0.0))
        self.u = float(kw.get("u", 0.0))
        self.v = float(kw.get("v", 0.0))
        self.n_points = int(kw.get("n_points", 0))
        self.width_m = float(kw.get("width_m", 0.0))
        self.depth_std = float(kw.get("depth_std", 0.0))
        self.peak_depth = float(kw.get("peak_depth", 0.0))

    def __repr__(self):
        if not self.valid:
            return "<LocateResult invalid: %s>" % self.reason
        return "<LocateResult X=%.3f Y=%.3f Z=%.3f n=%d>" % (
            self.X, self.Y, self.Z, self.n_points)


class DepthLocator(object):
    """
    bbox -> 3D 点。无状态，可复用。

    prior_d / prior_tol（时序先验）
        真机实测暴露：目标贴近相机时 bbox 会覆盖大半个画面，框内背景
        （1.9 m 处的墙面/家具）点数反超人体（0.3 m），直方图最高峰翻到
        背景上，距离在 0.32 与 1.89 之间反复跳变，单次跳幅 1.57 m。
        处理方式：给出上一帧可靠距离 prior_d 时，只在 prior_d ± prior_tol
        内搜索峰值。人正常行走时相邻帧位移远小于 0.6 m，该约束不损失
        可用性，却能直接排除背景峰。无 prior 时退化为全量程搜索。
    """

    def __init__(self, lower_ratio=0.60, d_min=0.30, d_max=3.00,
                 bin_width=0.02, peak_tol=0.15, min_points=200,
                 max_width=1.20, max_depth_std=0.45, prior_tol=0.60):
        self.lower_ratio = float(lower_ratio)
        self.d_min = float(d_min)
        self.d_max = float(d_max)
        self.bin_width = float(bin_width)
        self.peak_tol = float(peak_tol)
        self.min_points = int(min_points)
        self.max_width = float(max_width)
        self.max_depth_std = float(max_depth_std)
        self.prior_tol = float(prior_tol)

    def _search_range(self, prior_d, prior_tol):
        tol = self.prior_tol if prior_tol is None else float(prior_tol)
        if prior_d is not None and float(prior_d) > 0.0:
            lo = max(self.d_min, float(prior_d) - tol)
            hi = min(self.d_max, float(prior_d) + tol)
            if hi - lo >= 0.10:
                return lo, hi
        return self.d_min, self.d_max

    def locate(self, bbox, depth_m, K, prior_d=None, prior_tol=None):
        """
        参数
            bbox:    (x1, y1, x2, y2) 像素坐标，float 或 int 均可
            depth_m: HxW float32/uint16，单位由调用方保证为米
            K:       (fx, fy, cx, cy)
            prior_d: 上一帧可靠距离（米），None 表示无先验

        返回
            LocateResult
        """
        fx, fy, cx, cy = K
        h_img, w_img = depth_m.shape[:2]
        lo, hi = self._search_range(prior_d, prior_tol)

        x1, y1, x2, y2 = [int(round(float(v))) for v in bbox[:4]]
        x1 = max(0, min(x1, w_img - 1))
        x2 = max(0, min(x2, w_img))
        y1 = max(0, min(y1, h_img - 1))
        y2 = max(0, min(y2, h_img))
        if x2 - x1 < 8 or y2 - y1 < 8:
            return LocateResult(False, "bbox_too_small")

        # ---- 步骤 1：只取下 lower_ratio ----
        y_top = int(y1 + (y2 - y1) * (1.0 - self.lower_ratio))
        roi = depth_m[y_top:y2, x1:x2].astype(np.float64)

        # ---- 步骤 2：有效深度筛选（先验范围内）----
        valid = (roi > lo) & (roi < hi)
        n_valid = int(valid.sum())
        if n_valid < self.min_points:
            return LocateResult(False, "too_few_valid_depth(%d)" % n_valid)

        vals = roi[valid]

        # ---- 步骤 3：直方图找峰值 ----
        nbins = max(4, int(round((hi - lo) / self.bin_width)))
        hist, edges = np.histogram(vals, bins=nbins,
                                   range=(lo, hi))
        pi = int(np.argmax(hist))
        peak_d = 0.5 * (edges[pi] + edges[pi + 1])

        # ---- 步骤 4：峰值邻域保留 ----
        band = valid & (np.abs(roi - peak_d) <= self.peak_tol)
        n_band = int(band.sum())
        if n_band < self.min_points:
            return LocateResult(False, "peak_band_too_small(%d)" % n_band)

        # ---- 步骤 5：反投影 ----
        vv, uu = np.nonzero(band)          # roi 内局部坐标
        u = uu.astype(np.float64) + x1
        v = vv.astype(np.float64) + y_top
        d = roi[band]

        X = (u - cx) * d / fx
        Y = (v - cy) * d / fy
        Z = d

        # ---- 步骤 6：人体尺寸合理性 ----
        width_m = float(np.percentile(X, 98) - np.percentile(X, 2))
        depth_std = float(np.std(Z))
        if width_m > self.max_width:
            return LocateResult(False, "too_wide(%.2fm)" % width_m,
                                n_points=n_band, width_m=width_m,
                                depth_std=depth_std, peak_depth=peak_d)
        if depth_std > self.max_depth_std:
            return LocateResult(False, "depth_spread(%.2f)" % depth_std,
                                n_points=n_band, width_m=width_m,
                                depth_std=depth_std, peak_depth=peak_d)

        # ---- 步骤 7：中位数 ----
        return LocateResult(
            True, "",
            X=float(np.median(X)),
            Y=float(np.median(Y)),
            Z=float(np.median(Z)),
            u=float(np.median(u)),
            v=float(np.median(v)),
            n_points=n_band,
            width_m=width_m,
            depth_std=depth_std,
            peak_depth=peak_d,
        )

    def collect_mask(self, bbox, depth_m, prior_d=None, prior_tol=None):
        """
        供可视化用：返回 (mask, y_top)。mask 与 depth_m 同形，仅在入池点为真。
        与 locate() 使用同一判据（含 prior 约束），确保画出来的点就是算出来的点。
        """
        h_img, w_img = depth_m.shape[:2]
        lo, hi = self._search_range(prior_d, prior_tol)
        mask = np.zeros(depth_m.shape, dtype=bool)
        x1, y1, x2, y2 = [int(round(float(v))) for v in bbox[:4]]
        x1 = max(0, min(x1, w_img - 1)); x2 = max(0, min(x2, w_img))
        y1 = max(0, min(y1, h_img - 1)); y2 = max(0, min(y2, h_img))
        if x2 - x1 < 8 or y2 - y1 < 8:
            return mask, y1

        y_top = int(y1 + (y2 - y1) * (1.0 - self.lower_ratio))
        roi = depth_m[y_top:y2, x1:x2].astype(np.float64)
        valid = (roi > lo) & (roi < hi)
        if valid.sum() < 4:
            return mask, y_top

        nbins = max(4, int(round((hi - lo) / self.bin_width)))
        hist, edges = np.histogram(roi[valid], bins=nbins, range=(lo, hi))
        pi = int(np.argmax(hist))
        peak_d = 0.5 * (edges[pi] + edges[pi + 1])
        band = valid & (np.abs(roi - peak_d) <= self.peak_tol)
        mask[y_top:y2, x1:x2] = band
        return mask, y_top


def camera_to_base(X, Y, Z, extrinsic):
    """
    相机光学系 -> base_link。

    extrinsic = (tx, ty, tz, rpy)
      URDF 实测：base_link -> camera_color_optical_frame
      平移 (0.160, 0.0325, 0.242)，rpy(-pi/2, 0, -pi/2)

    光学系约定：X 右、Y 下、Z 前。
    base_link 约定：X 前、Y 左、Z 上。
    """
    from math import sin, cos

    tx, ty, tz, rpy = extrinsic
    r, p, y_ = rpy

    # R = Rz(yaw) * Ry(pitch) * Rx(roll)
    cr, sr = cos(r), sin(r)
    cp, sp = cos(p), sin(p)
    cy_, sy_ = cos(y_), sin(y_)

    R00 = cy_ * cp
    R01 = cy_ * sp * sr - sy_ * cr
    R02 = cy_ * sp * cr + sy_ * sr
    R10 = sy_ * cp
    R11 = sy_ * sp * sr + cy_ * cr
    R12 = sy_ * sp * cr - cy_ * sr
    R20 = -sp
    R21 = cp * sr
    R22 = cp * cr

    bx = R00 * X + R01 * Y + R02 * Z + tx
    by = R10 * X + R11 * Y + R12 * Z + ty
    bz = R20 * X + R21 * Y + R22 * Z + tz
    return float(bx), float(by), float(bz)
