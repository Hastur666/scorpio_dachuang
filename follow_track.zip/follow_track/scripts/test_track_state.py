# -*- coding: utf-8 -*-
"""
track_state 自测。合成数据，无需相机与数据集。

覆盖 S3 的三条验收指标，外加三条鲁棒性：
    T1 静止目标 + 噪声      -> 抖动抑制倍数
    T2 匀速 1.0 m/s         -> 速度估计收敛
    T3 快速 1.5 m/s         -> 跟上能力（会不会被门控误拒）
    T4 单点离群 +0.50 m     -> 门控拒绝
    T5 断流 20 帧           -> 预测漂移是否可控
    T6 含 1.1 s 卡顿        -> 数值稳定
    T7 reset                -> ID 切换不继承旧状态
"""

import numpy as np

from track_state import TrackFilter

OK = []
FAIL = []


def check(name, cond, detail=""):
    (OK if cond else FAIL).append(name)
    print("  [%s] %s%s" % ("PASS" if cond else "FAIL", name,
                           ("  " + detail) if detail else ""))


def synth(t, x0, y0, vx, vy, sigma=0.08, seed=0):
    """给定真值轨迹，生成带噪声的观测序列。"""
    rng = np.random.RandomState(seed)
    return np.column_stack([x0 + vx * t, y0 + vy * t]) + rng.randn(len(t), 2) * sigma


# ---------------------------------------------------------------- T1
def t1():
    print("T1 静止目标：平滑抑制抖动")
    dt = 0.065
    t = np.arange(0, 10.0, dt)
    z = synth(t, 0.10, 1.20, 0.0, 0.0, sigma=0.08, seed=1)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    out = [f.step(ti, zi) for ti, zi in zip(t, z)]

    # 跳过前 20 帧收敛期
    obs = z[20:]
    est = np.array([[o["x"], o["y"]] for o in out[20:]])

    d_obs = np.diff(obs, axis=0)
    d_est = np.diff(est, axis=0)
    sd_obs = float(np.std(np.linalg.norm(d_obs, axis=1)))
    sd_est = float(np.std(np.linalg.norm(d_est, axis=1)))
    ratio = sd_obs / max(1e-9, sd_est)

    print("    相邻帧位移 std:  观测 %.4f m   估计 %.4f m   抑制 %.1f 倍"
          % (sd_obs, sd_est, ratio))
    err = float(np.mean(np.linalg.norm(est - np.array([0.10, 1.20]), axis=1)))
    print("    稳态位置误差:    %.4f m" % err)
    check("抖动抑制 > 3 倍", ratio > 3.0, "%.1f 倍" % ratio)
    check("稳态误差 < 0.05 m", err < 0.05, "%.4f m" % err)


# ---------------------------------------------------------------- T2
def t2():
    print("T2 匀速 1.0 m/s：速度估计收敛")
    dt = 0.065
    t = np.arange(0, 8.0, dt)
    z = synth(t, 0.0, 1.50, 0.0, -1.0, sigma=0.08, seed=2)   # 沿 y 负向 1 m/s

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    out = [f.step(ti, zi) for ti, zi in zip(t, z)]

    vz = np.array([o["vy"] for o in out])
    # 收敛时间：连续 20 帧进入 ±0.15 m/s
    conv = None
    for i in range(len(vz) - 20):
        if np.all(np.abs(vz[i:i + 20] + 1.0) < 0.15):
            conv = t[i]
            break
    final = float(np.mean(vz[-40:]))
    print("    收敛时间 %s   末段平均 vy %.3f m/s（真值 -1.000）"
          % ("%.2f s" % conv if conv else "未收敛", final))
    check("速度收敛 < 2.0 s", conv is not None and conv < 2.0,
          "%.2f s" % conv if conv else "-")
    check("稳态速度误差 < 0.10 m/s", abs(final + 1.0) < 0.10, "%.3f" % final)


# ---------------------------------------------------------------- T3
def t3():
    print("T3 快速 1.5 m/s：门控是否误拒")
    dt = 0.065
    t = np.arange(0, 6.0, dt)
    z = synth(t, 0.0, 3.00, 0.0, -1.5, sigma=0.08, seed=3)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    out = [f.step(ti, zi) for ti, zi in zip(t, z)]
    s = f.stats()
    vz = np.array([o["vy"] for o in out])
    final = float(np.mean(vz[-40:]))

    print("    门控拒绝 %d / 接受 %d   拒绝率 %.1f%%"
          % (s["n_gate_reject"], s["n_update"], 100.0 * s["gate_reject_ratio"]))
    print("    末段 vy %.3f m/s（真值 -1.500）" % final)
    check("快速运动拒绝率 < 10%", s["gate_reject_ratio"] < 0.10,
          "%.1f%%" % (100.0 * s["gate_reject_ratio"]))
    check("快速运动速度误差 < 0.20 m/s", abs(final + 1.5) < 0.20, "%.3f" % final)


# ---------------------------------------------------------------- T4
def t4():
    print("T4 单点离群：门控拒绝幅度阈值")
    dt = 0.065
    t = np.arange(0, 2.0, dt)
    z = synth(t, 0.0, 1.20, 0.0, 0.0, sigma=0.08, seed=4)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    for ti, zi in zip(t, z):
        f.step(ti, zi)

    st = f.step(t[-1] + dt, None)          # 先预测一帧，让 P 略增
    for mag in (0.15, 0.25, 0.40, 0.60, 1.00):
        f2 = TrackFilter(sigma_obs=0.08, q_acc=0.6)
        for ti, zi in zip(t, z):
            f2.step(ti, zi)
        f2.step(t[-1] + dt, None)
        zz = np.array([0.0, 1.20 + mag])
        acc, nis = f2.update(zz)
        print("    偏离 %+.2f m -> %s (NIS %.1f)"
              % (mag, "接受" if acc else "拒绝", nis))
        if mag >= 0.40:
            check("偏离 %.2f m 被拒绝" % mag, not acc, "NIS %.1f" % nis)
        if mag <= 0.15:
            check("偏离 %.2f m 被接受" % mag, acc, "NIS %.1f" % nis)

    # 连续同一方向离群：门控不应永久拒绝（需靠重初始化）
    print("    （连续离群需上层调用 reset，属已知边界）")
    _ = st


# ---------------------------------------------------------------- T5
def t5():
    print("T5 断流 20 帧：预测漂移")
    dt = 0.065
    t = np.arange(0, 4.0, dt)
    z = synth(t, 0.0, 2.00, 0.0, -1.0, sigma=0.05, seed=5)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    for ti, zi in zip(t, z):
        f.step(ti, zi)

    t_last = t[-1]
    drift = []
    for k in range(1, 21):
        o = f.step(t_last + k * dt, None)
        truth = 2.00 - 1.0 * (t_last + k * dt)
        drift.append(abs(o["y"] - truth))

    print("    断流期最大漂移 %.3f m（末帧 %.3f m）" % (max(drift), drift[-1]))
    check("断流 20 帧漂移 < 0.15 m", max(drift) < 0.15, "%.3f m" % max(drift))

    # 恢复供观测后应能接上
    o = f.step(t_last + 21 * dt, np.array([0.0, 2.00 - 1.0 * (t_last + 21 * dt)]))
    print("    恢复后 accepted=%s  y=%.3f" % (o["accepted"], o["y"]))
    check("断流后能恢复", o["accepted"])


# ---------------------------------------------------------------- T6
def t6():
    print("T6 变长间隔（含 1.1 s 卡顿）：数值稳定")
    gaps = [0.065, 0.066, 0.062, 1.113, 0.064, 0.070, 0.065, 0.900, 0.065]
    t = np.cumsum([0.0] + gaps)
    z = synth(t, 0.0, 2.00, 0.0, -0.8, sigma=0.08, seed=6)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    out = [f.step(ti, zi) for ti, zi in zip(t, z)]
    vals = np.array([[o["y"], o["vy"]] for o in out])
    finite = bool(np.all(np.isfinite(vals)))
    s = f.stats()
    print("    全部有限值 %s   dt 截断 %d 次   位置范围 %.2f..%.2f"
          % (finite, s["n_dt_clamped"], vals[:, 0].min(), vals[:, 0].max()))
    check("无 NaN/Inf", finite)
    check("触发 dt 截断保护", s["n_dt_clamped"] >= 1, "%d 次" % s["n_dt_clamped"])
    check("位置未越过真值范围", vals[:, 0].max() < 2.5 and vals[:, 0].min() > 0.0)


# ---------------------------------------------------------------- T7
def t7():
    print("T7 reset：ID 切换不继承旧状态")
    dt = 0.065
    t = np.arange(0, 2.0, dt)
    z1 = synth(t, 0.0, 1.20, 0.0, 0.0, sigma=0.05, seed=7)

    f = TrackFilter(sigma_obs=0.08, q_acc=0.6)
    for ti, zi in zip(t, z1):
        f.step(ti, zi)
    v_before = abs(f.x[2]) + abs(f.x[3])

    f.reset()
    o = f.step(t[-1] + dt, np.array([0.8, 3.00]))
    print("    重置前速度绝对值 %.3f   重置后位置 (%.2f, %.2f) 速度 %.2f"
          % (v_before, o["x"], o["y"], o["speed"]))
    check("重置后位置等于新观测", abs(o["x"] - 0.8) < 1e-6 and abs(o["y"] - 3.0) < 1e-6)
    check("重置后速度归零", o["speed"] < 1e-6)


# ---------------------------------------------------------------- T8
def t8():
    print("T8 单帧大跳变：被拒但状态不动")
    f = TrackFilter()
    f.step(0.0, np.array([2.0, 0.0]))
    o = f.step(0.033, np.array([3.5, 0.0]))
    print("    accepted=%s nis=%.1f x=%.2f" % (o["accepted"], o["nis"], o["x"]))
    check("被门控拒绝", not o["accepted"])
    check("状态不跟着跳", abs(o["x"] - 2.0) < 0.05, "x=%.2f" % o["x"])
    check("未触发重定位", f.n_reinit == 0, "n_reinit=%d" % f.n_reinit)


# ---------------------------------------------------------------- T9
def t9():
    print("T9 持续大跳变：8 帧后重定位，不永久卡死")
    f = TrackFilter()
    f.step(0.0, np.array([2.0, 0.0]))
    t = 0.0
    for _ in range(9):
        t += 0.033
        o = f.step(t, np.array([3.6, 0.0]))
    print("    重定位 %d 次  位置 %.2f  x_std %.3f"
          % (f.n_reinit, o["x"], o["pos_std"]))
    check("触发了重定位", f.n_reinit >= 1, "n_reinit=%d" % f.n_reinit)
    check("位置已跟上新观测", abs(o["x"] - 3.6) < 0.25, "x=%.2f" % o["x"])


# ---------------------------------------------------------------- T10
def t10():
    print("T10 正常噪声不误触发重定位")
    rng = np.random.RandomState(0)
    f = TrackFilter()
    t = 0.0
    for _ in range(300):
        t += 0.066
        z = np.array([2.0 + rng.randn() * 0.04, 0.0 + rng.randn() * 0.04])
        f.step(t, z)
    n_rej = f.n_gate_reject
    n_acc = f.n_update
    print("    重定位 %d 次  接受 %d 拒绝 %d" % (f.n_reinit, n_acc, n_rej))
    check("无误触发", f.n_reinit == 0, "n_reinit=%d" % f.n_reinit)


if __name__ == "__main__":
    print("=" * 58)
    print("track_state 自测")
    print("=" * 58)
    for fn in (t1, t2, t3, t4, t5, t6, t7, t8, t9, t10):
        fn()
        print()
    print("=" * 58)
    print("通过 %d  失败 %d" % (len(OK), len(FAIL)))
    if FAIL:
        print("失败项: %s" % ", ".join(FAIL))
    print("=" * 58)
