# -*- coding: utf-8 -*-
"""
vision_verify.py —— 用视觉框佐证雷达目标，防止锁到桌腿/墙柱。

思路
    雷达无法识别"这是不是人"，但能给出精确位置。把雷达目标投影到
    图像平面，看它是否落在某个 person 框里：
        落在框内 -> 视觉上那个位置确实有人，佐证通过
        不在框内 -> 可能是桌腿、椅腿、柱子，降低置信度

    这不等于 ReID。它只回答"这个位置此刻有没有人"，不回答
    "是不是原来那个人"。身份仍然靠位置连续性维持。

坐标链
    base_link(x 前, y 左, z 上)
      -> camera_color_optical_frame(x 右, y 下, z 前)   外参逆变换
      -> 像素 (u, v)                                   针孔投影
"""

import math


def base_to_camera(X, Y, Z, extrinsic):
    """base_link -> 相机光学系。extrinsic 与 depth_locator 同一份。"""
    tx, ty, tz, rpy = extrinsic
    r, p, y_ = rpy
    cr, sr = math.cos(r), math.sin(r)
    cp, sp = math.cos(p), math.sin(p)
    cy_, sy_ = math.cos(y_), math.sin(y_)

    # 与 camera_to_base 同一旋转矩阵
    R00 = cy_ * cp
    R01 = cy_ * sp * sr - sy_ * cr
    R02 = cy_ * sp * cr + sy_ * sr
    R10 = sy_ * cp
    R11 = sy_ * sp * sr + cy_ * cr
    R12 = sy_ * sp * cr - cy_ * sr
    R20 = -sp
    R21 = cp * sr
    R22 = cp * cr

    dx, dy, dz = X - tx, Y - ty, Z - tz
    # p_cam = R^T · (p_base - t)
    cx = R00 * dx + R10 * dy + R20 * dz
    cy = R01 * dx + R11 * dy + R21 * dz
    cz = R02 * dx + R12 * dy + R22 * dz
    return cx, cy, cz


def base_to_pixel(X, Y, Z, extrinsic, K):
    """base_link 点投到像素。返回 (u, v) 或 None（在相机后方）。"""
    cx, cy, cz = base_to_camera(X, Y, Z, extrinsic)
    if cz <= 0.05:            # 在相机后方或贴太近，投影无意义
        return None
    fx, fy, px, py = K
    u = fx * cx / cz + px
    v = fy * cy / cz + py
    return (u, v)


def in_any_box(u, v, boxes, margin=25.0):
    """判断像素点是否落在任一框内（含 margin 像素容差）。

    boxes: [(x1, y1, x2, y2), ...] 像素坐标
    margin 用于容忍雷达扫小腿、而框只包含上半身的情形。
    """
    for b in boxes:
        x1, y1, x2, y2 = b[:4]
        if (x1 - margin) <= u <= (x2 + margin) and \
           (y1 - margin) <= v <= (y2 + margin):
            return True
    return False


class VisionVerifier(object):
    """带滞回的视觉佐证器。

    单帧不在框内不代表锁错（人可能刚跨出框、YOLO 漏检一帧）。
    连续 counter_max 帧都不在框内，才判定为"视觉上那个位置没人"。
    """

    def __init__(self, counter_max=5, margin=25.0):
        self.counter_max = int(counter_max)
        self.margin = float(margin)
        self.bad = 0

    def reset(self):
        self.bad = 0

    def check(self, xb, yb, boxes, extrinsic, K, z=0.0):
        """返回 True 表示通过（或无法判断），False 表示判定为误锁。

        boxes 为空时无法佐证，直接通过——不能因为 YOLO 漏检就否定雷达。
        """
        if not boxes:
            self.bad = 0
            return True
        px = base_to_pixel(xb, yb, z, extrinsic, K)
        if px is None:
            self.bad = 0
            return True
        if in_any_box(px[0], px[1], boxes, self.margin):
            self.bad = 0
            return True
        self.bad += 1
        return self.bad < self.counter_max
