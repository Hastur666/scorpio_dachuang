#!/bin/bash
# run_s2.sh —— 在独立 ROS master 上运行 S2，不干扰 11311 上的任何进程
#
# 设计约束（对应工程规范守则）：
#   1. 独立端口 11319，不碰 11311
#   2. ROS_HOME / ROS_LOG_DIR 指向 /tmp，不写 ~/.ros
#   3. 退出时只清理本脚本启动的 PID，绝不 killall
#   4. 项目目录只写 logs/，不写他人目录
#
# 用法：
#   bash scripts/run_s2.sh                 # 默认 25 秒
#   DURATION=40 bash scripts/run_s2.sh     # 自定义时长
#
# 注意：禁用 set -u。ROS 1 的 setup.bash 会引用未定义变量，
#       在 set -u 下 source 会直接终止整个 shell（表现为脚本静默退出）。
set +u

PORT="${PORT:-11319}"
DURATION="${DURATION:-25}"
PROJ="$(cd "$(dirname "$0")/.." && pwd)"
LOGDIR="$PROJ/logs"
TMPD="/tmp/wb_s2_$$"

# 原始流录制（默认开）：保留 RGB + 16 位深度，作为可复用的离线回归素材
RAW="${RAW:-1}"
TS="$(date +%Y%m%d_%H%M%S)"
RAWDIR="$PROJ/data/raw_$TS"
RAW_ARG=""
if [ "$RAW" = "1" ]; then
    RAW_ARG="--record-raw $RAWDIR"
fi

mkdir -p "$LOGDIR" "$TMPD"
export ROS_MASTER_URI="http://localhost:$PORT"
export ROS_HOME="$TMPD/ros_home"
export ROS_LOG_DIR="$TMPD/ros_home/log"
mkdir -p "$ROS_LOG_DIR"

source /opt/ros/noetic/setup.bash 2>/dev/null
[ -f "$HOME/scorpio/devel/setup.bash" ] && source "$HOME/scorpio/devel/setup.bash" 2>/dev/null

CORE_PID=""
CAM_PID=""
NODE_PID=""

cleanup() {
    rc=$?
    echo
    echo "--- 清理（仅本脚本启动的进程）---"
    [ -n "$NODE_PID" ] && kill -INT "$NODE_PID" 2>/dev/null && wait "$NODE_PID" 2>/dev/null
    if [ -n "$CAM_PID" ]; then
        kill -INT "$CAM_PID" 2>/dev/null
        for _ in $(seq 1 10); do kill -0 "$CAM_PID" 2>/dev/null || break; sleep 0.5; done
        kill -TERM "$CAM_PID" 2>/dev/null
    fi
    if [ -n "$CORE_PID" ]; then
        kill -TERM "$CORE_PID" 2>/dev/null
        for _ in $(seq 1 10); do kill -0 "$CORE_PID" 2>/dev/null || break; sleep 0.3; done
    fi
    sleep 1
    echo "本脚本相关残留进程："
    pgrep -af "roscore -p $PORT|realsense2_camera|wb_s2_locate" 2>/dev/null | head -5 || echo "  无"

    # 失败时保留日志供诊断，成功才清理临时目录
    if [ "${NODE_RC:-1}" -ne 0 ] || [ ! -f "$LOGDIR/s2_result.mp4" ]; then
        cp "$TMPD/cam.out" "$LOGDIR/diag_cam.log" 2>/dev/null
        cp "$TMPD/s2.out"  "$LOGDIR/diag_node.log" 2>/dev/null
        cp "$TMPD/core.out" "$LOGDIR/diag_core.log" 2>/dev/null
        echo "运行未成功，诊断日志已保留到 $LOGDIR/diag_*.log"
        echo "临时目录保留: $TMPD"
    else
        rm -rf "$TMPD"
        echo "临时目录已删除: $TMPD"
    fi
    echo "11311 master 未受影响：$(pgrep -c rosmaster 2>/dev/null || echo 0) 个 rosmaster 进程仍在（若有）"
    exit $rc
}
trap cleanup EXIT INT TERM

echo "########## S2 启动前检查 ##########"
if (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -q ":$PORT "; then
    echo "端口 $PORT 已被占用，中止（避免干扰他人）"
    exit 1
fi
echo "端口 $PORT 空闲"

for d in /dev/video0 /dev/video2; do
    if fuser "$d" >/dev/null 2>&1; then
        echo "$d 已被占用（PID: $(fuser "$d" 2>&1)），相机可能正被他人使用"
        echo "若确认可用请输入 y 继续，否则回车退出："
        read -r ans
        [ "$ans" = "y" ] || exit 1
    else
        echo "$d 空闲"
    fi
done

echo
echo "########## 1/4 启动 roscore (端口 $PORT) ##########"
roscore -p "$PORT" >"$TMPD/core.out" 2>&1 &
CORE_PID=$!
for _ in $(seq 1 20); do
    rosnode list >/dev/null 2>&1 && break
    sleep 0.5
done
echo "roscore PID=$CORE_PID"

echo
echo "########## 2/4 启动相机 ##########"
roslaunch realsense2_camera rs_rgbd.launch align_depth:=true \
    >"$TMPD/cam.out" 2>&1 &
CAM_PID=$!
echo "相机 PID=$CAM_PID，等待话题就绪（最多 40 秒）"

READY=0
for i in $(seq 1 40); do
    if rostopic list 2>/dev/null | grep -qx "/camera/color/image_raw"; then
        if rostopic list 2>/dev/null | grep -qx "/camera/aligned_depth_to_color/image_raw"; then
            READY=1
            echo "话题就绪（${i}s）"
            break
        fi
    fi
    if ! kill -0 "$CAM_PID" 2>/dev/null; then
        echo "相机进程已退出，日志尾部："
        tail -20 "$TMPD/cam.out"
        exit 1
    fi
    sleep 1
done

if [ "$READY" -ne 1 ]; then
    echo "等待超时，日志尾部："
    tail -20 "$TMPD/cam.out"
    exit 1
fi
sleep 3   # 让首帧与 auto-exposure 稳定

echo
echo "########## 3/4 运行 S2 节点（${DURATION}s）##########"
echo "现在请站到相机前：走近 -> 停 -> 后退 -> 贴墙站 -> 侧移"
echo
"$HOME/follow/venv/bin/python" "$PROJ/scripts/s2_live.py" \
    --model "$HOME/follow/models/yolov8n.pt" \
    --out "$LOGDIR/s2_result.mp4" \
    --duration "$DURATION" \
    $RAW_ARG \
    2>&1 | tee "$TMPD/s2.out"
NODE_RC=${PIPESTATUS[0]}

echo
echo "########## 4/4 结果 ##########"
ls -lh "$LOGDIR"/s2_result.* 2>/dev/null

if [ "$RAW" = "1" ] && [ -d "$RAWDIR" ]; then
    echo
    echo "原始流: $RAWDIR"
    echo "  color/ $(ls "$RAWDIR/color" 2>/dev/null | wc -l) 帧"
    echo "  depth/ $(ls "$RAWDIR/depth" 2>/dev/null | wc -l) 帧"
    echo "  体积   $(du -sh "$RAWDIR" 2>/dev/null | cut -f1)"
fi

if [ -f "$TMPD/cam.out" ]; then
    ERRS=$(grep -icE "error|failed" "$TMPD/cam.out" 2>/dev/null)
    echo "相机日志错误行数: ${ERRS:-0}（仅供参考，个别 WARN 属正常）"
fi

exit "$NODE_RC"
