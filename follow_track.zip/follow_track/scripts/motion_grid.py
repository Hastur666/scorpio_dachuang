# -*- coding: utf-8 -*-
"""
motion_grid.py —— 占用栅格动静检测，区分"会动的人"和"静止的桌腿/墙柱"。

核心思想（带衰减的命中计数）
    单帧无法区分人腿和桌腿，但时间上有强先验：桌腿/墙柱是静止的，
    每帧都在同一位置被扫描到；人腿会移动，即使人站定，身体也有微小
    晃动，且一旦走动就换位置。

    每帧更新：
        - 命中的格子 +HIT_INC
        - 所有格子 -DECAY（衰减）
    静止物：每帧命中，净增长，很快超过静态阈值。
    人腿：在相邻格子间跳，单个格子难累积；即使短暂停留，一旦走开
          旧格子就衰减下去。

坐标系与车运动
    栅格在车体坐标系。车不动时，静止物在车体系里固定，判断准确。
    车在动时，静止物在车体系里反而"移动"，栅格会失效。因此：
    - 只在"视觉丢失、需要雷达独立找目标"时才启用动静过滤；
    - 启用时若车在移动（车速大），应降低栅格可信度（本类不做车速
      判断，由上层决定是否启用过滤）。

用法
    grid = MotionGrid()
    grid.update(points)      # points: [(x, y), ...] 车体系，每帧调用
    grid.is_static(x, y)     # 该位置附近是否为静态物
    grid.reset()             # 清空（视觉重捕后调用）
"""

import math


CELL = 0.10          # 栅格边长（米）
HIT_INC = 2          # 命中一次增加的计数
DECAY = 1            # 每帧衰减量
HIT_STATIC = 8       # 计数达到此值判为静态（约 0.4~0.8s 持续命中）
STABLE_DIST = 0.15   # 判定静态时允许的位置抖动（米）
MAX_CELLS = 4000     # 栅格容量上限，防内存无限增长


class MotionGrid(object):
    def __init__(self, cell=CELL, hit_static=HIT_STATIC):
        self.cell = float(cell)
        self.hit_static = int(hit_static)
        self.cells = {}          # (ix, iy) -> [count, last_x, last_y]

    def _key(self, x, y):
        return (int(math.floor(x / self.cell)),
                int(math.floor(y / self.cell)))

    def update(self, points):
        """用一帧扫描点更新栅格。points: [(x, y), ...] 车体系。"""
        # 先对所有旧格子衰减
        dead = []
        for k, rec in self.cells.items():
            rec[0] -= DECAY
            if rec[0] <= 0:
                dead.append(k)
        for k in dead:
            del self.cells[k]

        # 命中计数
        seen = set()
        for x, y in points:
            k = self._key(x, y)
            if k in seen:
                continue
            seen.add(k)
            rec = self.cells.get(k)
            if rec is None:
                self.cells[k] = [HIT_INC, x, y]
            else:
                rec[0] += HIT_INC
                rec[0] = min(rec[0], self.hit_static * 3)  # 防溢出
                rec[1] = x
                rec[2] = y

        if len(self.cells) > MAX_CELLS:
            self._prune()

    def _prune(self):
        items = sorted(self.cells.items(), key=lambda kv: -kv[1][0])
        self.cells = dict(items[:MAX_CELLS])

    def is_static(self, x, y):
        """查询 (x,y) 附近是否存在静态物。返回 True/False。"""
        ix, iy = self._key(x, y)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                rec = self.cells.get((ix + dx, iy + dy))
                if rec is not None and rec[0] >= self.hit_static:
                    d = math.hypot(rec[1] - x, rec[2] - y)
                    if d < STABLE_DIST:
                        return True
        return False

    def reset(self):
        self.cells = {}
