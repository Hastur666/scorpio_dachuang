# -*- coding: utf-8 -*-
"""验证：卡尔曼状态建在世界系 vs 车体系。

真机故障复现条件：车在走，人静止。车体系会把坐标系自身的运动当成目标跳变，
马氏门控全部拒绝，控制随即失效。

期望：世界系拒绝率低、位置误差小；车体系拒绝率高。
"""

import math

import numpy as np

from odometry import Odometry
from track_state import TrackFilter

DT_CTRL = 0.033
DT_OBS = 0.066          # 感知 15 Hz


def run(use_world, v=0.25, delta=0.0, dur=4.0, noise=0.02, seed=1,
        tx=2.0, ty=0.0):
    rng = np.random.RandomState(seed)
    odom = Odometry()
    kf = TrackFilter(sigma_obs=0.08, q_acc=0.6, max_speed=1.2)

    t = 0.0
    next_obs = 0.0
    n_acc = n_rej = 0
    errs = []

    while t < dur:
        odom.predict(t)

        if t >= next_obs:
            next_obs += DT_OBS
            bx, by = odom.to_body(tx, ty)
            ox = bx + rng.randn() * noise
            oy = by + rng.randn() * noise
            if use_world:
                wx, wy = odom.to_world(ox, oy)
                obs = np.array([wx, wy])
            else:
                obs = np.array([ox, oy])
            st = kf.step(t, obs)
            if st["accepted"]:
                n_acc += 1
            else:
                n_rej += 1
        else:
            kf.step(t, None)

        if kf.initialized:
            if use_world:
                ex, ey = odom.to_body(kf.x[0], kf.x[1])
            else:
                ex, ey = kf.x[0], kf.x[1]
            bx, by = odom.to_body(tx, ty)
            errs.append(math.hypot(ex - bx, ey - by))

        odom.set_cmd(v, delta)
        t += DT_CTRL

    tot = max(1, n_acc + n_rej)
    return {
        "reject": n_rej / float(tot),
        "n_acc": n_acc,
        "n_rej": n_rej,
        "err_med": float(np.median(errs)) if errs else -1.0,
        "err_max": float(np.max(errs)) if errs else -1.0,
    }


def show(tag, r):
    print("  %-12s 接受 %3d 拒绝 %3d  拒绝率 %5.1f%%  误差 中位 %.3f 最大 %.3f m"
          % (tag, r["n_acc"], r["n_rej"], r["reject"] * 100,
             r["err_med"], r["err_max"]))


def main():
    print("=" * 74)
    print("车体坐标系 vs 世界坐标系（人静止在 (2.0, 0)，车在走）")
    print("=" * 74)

    ok = True
    for name, kw in (("直行 0.25 m/s", dict(v=0.25, delta=0.0)),
                     ("转圈 0.25, δ=0.3", dict(v=0.25, delta=0.3)),
                     ("直行 0.45 m/s", dict(v=0.45, delta=0.0))):
        print("\n%s" % name)
        body = run(False, **kw)
        world = run(True, **kw)
        show("车体系", body)
        show("世界系", world)
        if world["reject"] < 0.20 and world["err_med"] < 0.15:
            print("    [PASS] 世界系稳定")
        else:
            print("    [FAIL] 世界系仍不稳定")
            ok = False
        if body["reject"] > world["reject"]:
            print("    [PASS] 故障可复现：车体系拒绝率更高")
        else:
            print("    [WARN] 本次车体系未复现高拒绝（车速/噪声组合所致）")

    print("\n" + "=" * 74)
    print("结论：%s" % ("世界系方案有效" if ok else "世界系方案无效，需复查"))
    print("=" * 74)


if __name__ == "__main__":
    main()
