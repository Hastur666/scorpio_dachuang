#!/bin/bash
# run_s4.sh —— 在独立 ROS master 上运行 S4，默认 dry-run（不发任何速度指令）
#
# 设计约束（对应工程规范守则）：
#   1. 独立端口 11319，不碰 11311
#   2. ROS_HOME / ROS_LOG_DIR 指向 /tmp，不写 ~/.ros
#   3. 退出只清理本脚本启动的 PID，绝不 killall
#   4. 项目目录只写 logs/
#
# 用法：
#   bash scripts/run_s4.sh                          # dry-run，只打印指令
#   DURATION=20 bash scripts/run_s4.sh
#   ENABLE=1 VMAX=0.20 bash scripts/run_s4.sh       # 真的发指令，需二次确认
#
# 注意：禁用 set -u。ROS 1 的 setup.bash 会引用未定义变量，
#       在 set -u 下 source 会直接终止整个 shell（表现为脚本静默退出）。
set +u

PORT="${PORT:-11319}"
DURATION="${DURATION:-30}"
VMAX="${VMAX:-0.45}"
ENABLE="${ENABLE:-0}"
PROJ="$(cd "$(dirname "$0")/.." && pwd)"
LOGDIR="$PROJ/logs"
TMPD="/tmp/wb_s4_$$"

mkdir -p "$LOGDIR" "$TMPD"
export ROS_MASTER_URI="http://localhost:$PORT"
export ROS_HOME="$TMPD/ros_home"
export ROS_LOG_DIR="$TMPD/ros_home/log"
mkdir -p "$ROS_LOG_DIR"

source /opt/ros/noetic/setup.bash 2>/dev/null
[ -f "$HOME/scorpio/devel/setup.bash" ] && source "$HOME/scorpio/devel/setup.bash" 2>/dev/null

CORE_PID=""
CAM_PID=""
BASE_PID=""
NODE_PID=""

cleanup() {
    rc=$?
    echo
    echo "--- 清理（仅本脚本启动的进程）---"
    # 底盘日志必须留存：过流保护关电机的唯一证据就在这份日志里
    [ -f "$TMPD/base.out" ] && cp -f "$TMPD/base.out" "$LOGDIR/s4_base.log" 2>/dev/null
    [ -n "$NODE_PID" ] && kill -INT "$NODE_PID" 2>/dev/null && wait "$NODE_PID" 2>/dev/null
    # 底盘驱动先停：确保退出前不再有指令发布者
    if [ -n "$BASE_PID" ]; then
        kill -INT "$BASE_PID" 2>/dev/null
        for _ in $(seq 1 8); do kill -0 "$BASE_PID" 2>/dev/null || break; sleep 0.5; done
        kill -TERM "$BASE_PID" 2>/dev/null
        sleep 1
        rosnode kill /scorpio_base_driver >/dev/null 2>&1
    fi
    if [ -n "$CAM_PID" ]; then
        kill -INT "$CAM_PID" 2>/dev/null
        for _ in $(seq 1 10); do kill -0 "$CAM_PID" 2>/dev/null || break; sleep 0.5; done
        kill -TERM "$CAM_PID" 2>/dev/null
    fi
    if [ -n "$CORE_PID" ]; then
        kill -TERM "$CORE_PID" 2>/dev/null
        for _ in $(seq 1 10); do kill -0 "$CORE_PID" 2>/dev/null || break; sleep 0.3; done
    fi
    sleep 1
    echo "残留检查："
    pgrep -af "roscore -p $PORT|realsense2_camera|wb_s4_follow|scorpio_base_node" 2>/dev/null | head -5 || echo "  无"
    rm -rf "$TMPD"
    echo "临时目录已删除: $TMPD"
    exit $rc
}
trap cleanup EXIT INT TERM

echo "########## S4 启动前检查 ##########"
if (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -q ":$PORT "; then
    echo "端口 $PORT 已被占用，中止（避免干扰他人）"
    exit 1
fi
echo "端口 $PORT 空闲"

for d in /dev/video0 /dev/video2; do
    if fuser "$d" >/dev/null 2>&1; then
        echo "$d 已被占用（PID: $(fuser "$d" 2>&1)），相机可能正被他人使用"
        echo "若确认可用请输入 y 继续，否则回车退出："
        read -r ans
        [ "$ans" = "y" ] || exit 1
    else
        echo "$d 空闲"
    fi
done

if [ "$ENABLE" = "1" ]; then
    echo
    echo "!!! 本次会真的向 /ackermann_cmd 发布速度指令 !!!"
    echo "请确认：车轮已垫起 / 场地清空 / 有人能随时断电"
    echo "输入 YES 继续，其他任意输入退出："
    read -r ans
    [ "$ans" = "YES" ] || { echo "已取消"; exit 1; }
    ENABLE_ARG="--enable"
else
    echo "模式：dry-run（不发布任何速度）"
    ENABLE_ARG=""
fi

echo
echo "########## 1/4 roscore (端口 $PORT) ##########"
roscore -p "$PORT" >"$TMPD/core.out" 2>&1 &
CORE_PID=$!
for _ in $(seq 1 20); do
    rosnode list >/dev/null 2>&1 && break
    sleep 0.5
done
echo "roscore PID=$CORE_PID"

echo
echo "########## 2/4 相机 ##########"
roslaunch realsense2_camera rs_rgbd.launch align_depth:=true \
    >"$TMPD/cam.out" 2>&1 &
CAM_PID=$!
READY=0
for i in $(seq 1 40); do
    if rostopic list 2>/dev/null | grep -qx "/camera/color/image_raw" \
       && rostopic list 2>/dev/null | grep -qx "/camera/aligned_depth_to_color/image_raw"; then
        READY=1
        echo "话题就绪（${i}s）"
        break
    fi
    if ! kill -0 "$CAM_PID" 2>/dev/null; then
        echo "相机进程已退出，日志尾部："
        tail -20 "$TMPD/cam.out"
        exit 1
    fi
    sleep 1
done
[ "$READY" -eq 1 ] || { echo "等待超时"; tail -20 "$TMPD/cam.out"; exit 1; }
sleep 3

echo
echo "########## 3/5 底盘驱动 ##########"
if [ "$ENABLE" = "1" ]; then
    if fuser /dev/ttyS0 >/dev/null 2>&1; then
        echo "/dev/ttyS0 已被占用（PID: $(fuser /dev/ttyS0 2>&1)）"
        echo "继续会与现有驱动抢串口。输入 y 继续，其他退出："
        read -r ans2
        [ "$ans2" = "y" ] || exit 1
    fi
    # 必须走原厂 launch：hall_encoder 未显式赋值时是未初始化的 bool，
    # 会走进里程计发布分支并因空 publisher 崩溃。
    roslaunch scorpio_base scorpio_base.launch \
        serialport:=/dev/ttyS0 limited_speed:=1.0 \
        >"$TMPD/base.out" 2>&1 &
    BASE_PID=$!
    CONNECTED=0
    for _ in $(seq 1 15); do
        if rosnode list 2>/dev/null | grep -qx "/scorpio_base_driver"; then
            CONNECTED=1
            break
        fi
        kill -0 "$BASE_PID" 2>/dev/null || break
        sleep 1
    done
    if [ "$CONNECTED" -ne 1 ]; then
        echo "底盘驱动未启动，日志："
        cat "$TMPD/base.out"
        exit 1
    fi
    echo "底盘驱动已就绪 PID=$BASE_PID"
else
    echo "dry-run：不启动底盘驱动（不占用串口）"
fi

echo
echo "########## 4/5 S4 节点（${DURATION}s，v_max=${VMAX}）##########"
"$HOME/follow/venv/bin/python" "$PROJ/scripts/s4_live.py" \
    --model "$HOME/follow/models/yolov8n.pt" \
    --duration "$DURATION" \
    --vmax "$VMAX" \
    --visual --out "$LOGDIR/s4_live.mp4" \
    --csv "$LOGDIR/s4_live.csv" \
    --summary "$LOGDIR/s4_live_summary.json" \
    $ENABLE_ARG \
    2>&1 | tee "$TMPD/s4.out"
NODE_RC=${PIPESTATUS[0]}

# 留一份文本日志：$TMPD 退出时会被删，现场若来不及看屏幕可从日志复盘
cp -f "$TMPD/s4.out" "$LOGDIR/s4_live.log" 2>/dev/null

echo
echo "########## 5/5 结果 ##########"
ls -lh "$LOGDIR"/s4_live.* "$LOGDIR"/s4_base.log 2>/dev/null
if [ -f "$LOGDIR/s4_live_summary.json" ]; then
    echo "--- 关键数据 ---"
    cat "$LOGDIR/s4_live_summary.json"
    echo
fi
if [ -f "$TMPD/base.out" ]; then
    OC=$(grep -ci "overcurrent\|over current\|close motor\|closeMotor" "$TMPD/base.out" 2>/dev/null)
    echo "过流相关日志行数：${OC:-0}"
    [ "${OC:-0}" -gt 0 ] && grep -i "overcurrent\|close motor\|closeMotor" "$TMPD/base.out" | head -5
fi
exit "$NODE_RC"
