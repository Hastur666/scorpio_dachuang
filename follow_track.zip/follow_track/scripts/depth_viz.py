# -*- coding: utf-8 -*-
"""点云深度可视化：把对齐深度图反投影成 base_link 下的三维点云并画成斜视图。

为什么单独一个模块
    定位链路（depth_locator）只吐一个三维点和点数，看不出"这帧到底采到了
    什么"。验收要求里的"点云与视觉关联同一人""跟人不跟墙"，肉眼要能看到
    点云在哪儿、哪些点被选中、哪些墙点被丢掉。这个模块只做渲染，不参与
    任何判断，渲染结果与 locate() 用同一份 mask，保证"画出来的就是算出来的"。

视图约定
    base_link：x 前、y 左、z 上
    屏幕：先绕 z 转 yaw，再按 pitch 俯视投影，正交（不是透视）
    正交而不透视：距离数字用文字重申，透视会把 1 m 和 2 m 视觉差压扁
"""

import cv2
import numpy as np

W, H = 640, 480

C_BG = (28, 26, 24)
C_GRID = (60, 58, 55)
C_GRID_AXIS = (95, 90, 80)
C_CLOUD = (125, 125, 125)
C_SEL = (0, 220, 0)
C_PT = (0, 0, 255)
C_CAR = (255, 180, 60)
C_TXT = (235, 235, 235)
C_DIM = (150, 150, 150)


def _rigid(pts, extrinsic):
    """相机光学系 -> base_link，与 depth_locator.camera_to_base 同式（向量化）。"""
    tx, ty, tz, rpy = extrinsic
    r, p, y_ = rpy
    cr, sr = np.cos(r), np.sin(r)
    cp, sp = np.cos(p), np.sin(p)
    cy_, sy_ = np.cos(y_), np.sin(y_)

    R00 = cy_ * cp
    R01 = cy_ * sp * sr - sy_ * cr
    R02 = cy_ * sp * cr + sy_ * sr
    R10 = sy_ * cp
    R11 = sy_ * sp * sr + cy_ * cr
    R12 = sy_ * sp * cr - cy_ * sr
    R20 = -sp
    R21 = cp * sr
    R22 = cp * cr

    X, Y, Z = pts[:, 0], pts[:, 1], pts[:, 2]
    out = np.empty_like(pts)
    out[:, 0] = R00 * X + R01 * Y + R02 * Z + tx
    out[:, 1] = R10 * X + R11 * Y + R12 * Z + ty
    out[:, 2] = R20 * X + R21 * Y + R22 * Z + tz
    return out


def backproject(depth_m, K, extrinsic, step=4, d_min=0.25, d_max=3.2):
    """
    下采样反投影。

    返回 (pts Nx3 base 系, uu, vv) —— uu/vv 是保留点的像素坐标，
    调用方用它们去查 mask，保证点云与像素一一对应。
    """
    fx, fy, cx, cy = K
    h, w = depth_m.shape[:2]
    us = np.arange(0, w, step)
    vs = np.arange(0, h, step)
    uu, vv = np.meshgrid(us, vs)
    d = depth_m[vv, uu]

    keep = (d > d_min) & (d < d_max)
    if not keep.any():
        return np.zeros((0, 3)), uu[keep], vv[keep]

    u = uu[keep].astype(np.float64)
    v = vv[keep].astype(np.float64)
    z = d[keep].astype(np.float64)
    cam = np.stack([(u - cx) * z / fx, (v - cy) * z / fy, z], axis=1)
    return _rigid(cam, extrinsic), uu[keep], vv[keep]


def _make_view(yaw, pitch, scale, cx0, cy0, fwd_center):
    """
    返回把 base 系点投影到屏幕的闭包。

    yaw 绕 z 把场景转过来，使前进方向主要落到"屏幕进深 b"上；pitch 再把
    b 压成竖直位移。若像普通俯视图那样让 yaw 接近 90°，前进方向会被压成
    0，1 m 和 3 m 在画面上只差十几像素，距离就看不出差别了。
    """
    cy_, sy_ = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)

    def proj(pts):
        x = pts[:, 0] - fwd_center
        y = pts[:, 1]
        a = -y * cy_ - x * sy_          # 屏幕右（车右侧为负 y，落在画面右侧）
        b = x * cy_ - y * sy_           # 屏幕进深
        c = pts[:, 2]
        u = cx0 + a * scale
        v = cy0 - (b * sp + c * cp) * scale
        order = b * cp - c * sp         # 越大越远
        return u, v, order

    return proj


def _draw_poly(img, proj, pts, color, thick=1):
    u, v, _ = proj(np.asarray(pts, dtype=np.float64))
    p = np.stack([u, v], axis=1)
    ok = np.isfinite(p).all(axis=1)
    if not ok.all():
        p = p[ok]
    if len(p) < 2:
        return
    cv2.polylines(img, [np.round(p).astype(np.int32)], False, color, thick,
                  cv2.LINE_AA)


def render(depth_m, K, extrinsic, mask=None, tgt=None, trail=None,
           yaw_deg=28.0, pitch_deg=34.0, scale=110.0,
           step=3, d_max=3.2, pts_text="", extra=None):
    """
    画一帧点云斜视图。

    mask   : 与 depth 同形 bool，True 表示该像素被 locate() 选中
    tgt    : base 系目标点 (x, y, z)，None 表示本帧无有效定位
    trail  : [(x, y), ...] base 系轨迹，用于看运动方向
    extra  : 追加到左上角的文字行
    """
    img = np.full((H, W, 3), C_BG, dtype=np.uint8)
    proj = _make_view(np.radians(yaw_deg), np.radians(pitch_deg),
                      scale, W * 0.5, H * 0.66, 1.75)

    # ---- 地面网格（z=0），1 m 实线、0.5 m 淡线 ----
    for x in np.arange(-1.0, 5.01, 0.5):
        col = C_GRID_AXIS if abs(x - round(x)) < 1e-6 else C_GRID
        _draw_poly(img, proj, [(x, -2.6, 0.0), (x, 2.6, 0.0)], col, 1)
    for y in np.arange(-2.5, 2.51, 0.5):
        col = C_GRID_AXIS if abs(y - round(y)) < 1e-6 else C_GRID
        _draw_poly(img, proj, [(0.0, y, 0.0), (5.0, y, 0.0)], col, 1)

    # ---- 距离弧（以车为圆心），让"多远"能一眼读出来 ----
    for r in (1.0, 2.0, 3.0):
        th = np.linspace(-1.15, 1.15, 33)
        arc = [(r * np.cos(a), r * np.sin(a), 0.0) for a in th]
        _draw_poly(img, proj, arc, (70, 70, 62), 1)
        pu, pv, _ = proj(np.array([[r * np.cos(1.15), r * np.sin(1.15), 0.0]]))
        cv2.putText(img, "%dm" % r, (int(pu[0]) - 18, int(pv[0]) - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (95, 95, 88), 1, cv2.LINE_AA)

    # ---- 车体（0.45 x 0.34）+ 朝向箭头 ----
    car = np.array([(-0.22, -0.17, 0.02), (0.22, -0.17, 0.02),
                    (0.22, 0.17, 0.02), (-0.22, 0.17, 0.02)], dtype=np.float64)
    cu, cv_, _ = proj(car)
    quad = np.round(np.stack([cu, cv_], axis=1)).astype(np.int32)
    cv2.fillConvexPoly(img, quad, (55, 40, 22))
    cv2.polylines(img, [np.vstack([quad, quad[:1]])], False, C_CAR, 2, cv2.LINE_AA)
    _draw_poly(img, proj, [(0.0, 0.0, 0.02), (0.62, 0.0, 0.02)], C_CAR, 2)

    # ---- 全视场点云（灰）与选中点（绿）----
    pts, uu, vv = backproject(depth_m, K, extrinsic, step=step, d_max=d_max)
    n_all = len(pts)
    n_sel = 0
    if n_all:
        u, v, order = proj(pts)
        sel = np.zeros(n_all, dtype=bool)
        if mask is not None and mask.any():
            sel = mask[vv, uu]
            n_sel = int(sel.sum())

        # 远的先画，近的覆盖，避免背景点糊住前景
        idx = np.argsort(-order)
        for group_mask, color in ((~sel, C_CLOUD), (sel, C_SEL)):
            ii = idx[group_mask[idx]]
            if not len(ii):
                continue
            px = np.round(u[ii]).astype(np.int32)
            py = np.round(v[ii]).astype(np.int32)
            ok = (px >= 0) & (px < W - 1) & (py >= 1) & (py < H - 1)
            px, py = px[ok], py[ok]
            img[py, px] = color
            img[py - 1, px] = color
            img[py, px + 1] = color

    # ---- 轨迹 ----
    if trail:
        _draw_poly(img, proj, [(x, y, 0.02) for x, y in trail[-90:]], (0, 200, 255), 2)

    # ---- 目标：竖直投影线 + 点 ----
    if tgt is not None:
        tx, ty, tz = tgt
        _draw_poly(img, proj, [(tx, ty, 0.0), (tx, ty, max(0.05, tz))],
                   (60, 60, 235), 1)
        p = np.array([[tx, ty, tz]], dtype=np.float64)
        u, v, _ = proj(p)
        c = (int(np.clip(u[0], 0, W - 1)), int(np.clip(v[0], 0, H - 1)))
        cv2.circle(img, c, 5, C_PT, -1, cv2.LINE_AA)
        cv2.circle(img, c, 9, C_PT, 1, cv2.LINE_AA)
        cv2.putText(img, "%.2fm" % np.hypot(tx, ty), (c[0] + 12, c[1] - 14),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(img, "%.2fm" % np.hypot(tx, ty), (c[0] + 12, c[1] - 14),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (60, 60, 235), 1, cv2.LINE_AA)

    # ---- 文字 ----
    lines = ["POINT CLOUD  base_link  0.5m grid"]
    if pts_text:
        lines.append(pts_text)
    lines.append("pts=%d  used=%d" % (n_all, n_sel))
    if extra:
        lines.extend(extra)
    for i, s in enumerate(lines):
        y0 = 20 + i * 17
        cv2.putText(img, s, (8, y0), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(img, s, (8, y0), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    C_TXT if i == 0 else C_DIM, 1, cv2.LINE_AA)
    return img
