#!/bin/bash
# 底盘方向验证 —— 车轮必须垫离地！
# 依赖：drive_probe.py 同目录
# 不用 set -e（ROS setup.bash 会触发），显式检查

export ROS_MASTER_URI=http://127.0.0.1:11319

source /opt/ros/noetic/setup.bash
source ~/scorpio/devel/setup.bash

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE/.." || exit 1

BASE_PID=""
RC_PID=""

cleanup() {
  echo
  echo "########## 清理 ##########"
  if [ -n "$BASE_PID" ] && kill -0 "$BASE_PID" 2>/dev/null; then
    kill -INT "$BASE_PID" 2>/dev/null
    sleep 2
    kill -9 "$BASE_PID" 2>/dev/null
  fi
  if [ -n "$RC_PID" ] && kill -0 "$RC_PID" 2>/dev/null; then
    kill -INT "$RC_PID" 2>/dev/null
    sleep 2
    kill -9 "$RC_PID" 2>/dev/null
  fi
  /bin/rm -f /tmp/roscore_drive.log
  echo "已清理"
}
trap cleanup EXIT INT TERM

echo "########## 1/4 启动 master (11319) ##########"
roscore -p 11319 > /tmp/roscore_drive.log 2>&1 &
RC_PID=$!
sleep 4
kill -0 "$RC_PID" 2>/dev/null || { echo "master 启动失败"; cat /tmp/roscore_drive.log; exit 1; }
echo "master OK pid=$RC_PID"

echo "########## 2/4 启动底盘驱动 ##########"
~/scorpio/devel/lib/scorpio_base/scorpio_base_node /dev/ttyS0 > /tmp/base_drive.log 2>&1 &
BASE_PID=$!
sleep 5
grep -iE "connected|fatal|could not|error" /tmp/base_drive.log | head -5
kill -0 "$BASE_PID" 2>/dev/null || { echo "驱动启动失败"; cat /tmp/base_drive.log; exit 1; }

echo "########## 3/4 下发测试指令 ##########"
python3 scripts/drive_probe.py
RC=$?

echo "########## 4/4 结果 rc=$RC ##########"
echo "--- 驱动日志尾部 ---"
tail -8 /tmp/base_drive.log
exit $RC
