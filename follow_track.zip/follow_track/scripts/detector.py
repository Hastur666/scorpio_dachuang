# -*- coding: utf-8 -*-
"""
行人检测封装（YOLOv8）。

只输出 COCO person 类（cls==0），这是"不跟墙"的第一道防线：
墙面、桌腿、椅背不会产生 person 检测，从源头被排除。
"""

import numpy as np

PERSON_CLASS_ID = 0


class PersonDetector(object):
    """YOLOv8 行人检测器。"""

    def __init__(self, model_path, imgsz=640, conf=0.5, iou=0.45,
                 device="cpu", max_det=30):
        from ultralytics import YOLO

        self.imgsz = int(imgsz)
        self.conf = float(conf)
        self.iou = float(iou)
        self.device = str(device)
        self.max_det = int(max_det)
        self.model = YOLO(str(model_path))

        # 预热：首次推理包含模型加载与图优化，耗时不代表稳态性能
        warm = np.zeros((480, 640, 3), dtype=np.uint8)
        self.model(warm, imgsz=self.imgsz, device=self.device,
                   classes=[PERSON_CLASS_ID], verbose=False)

    def detect(self, frame_bgr):
        """
        参数
            frame_bgr: HxWx3 uint8 BGR

        返回
            np.ndarray, shape (N, 5), 每行 [x1, y1, x2, y2, score]
            无检测时返回 shape (0, 5) 的空数组（不是 None）
        """
        results = self.model(
            frame_bgr,
            imgsz=self.imgsz,
            conf=self.conf,
            iou=self.iou,
            device=self.device,
            classes=[PERSON_CLASS_ID],
            max_det=self.max_det,
            verbose=False,
        )

        if not results:
            return np.empty((0, 5), dtype=np.float64)

        boxes = results[0].boxes
        if boxes is None or len(boxes) == 0:
            return np.empty((0, 5), dtype=np.float64)

        xyxy = boxes.xyxy.cpu().numpy().astype(np.float64)
        scores = boxes.conf.cpu().numpy().astype(np.float64).reshape(-1, 1)
        return np.hstack([xyxy, scores])
