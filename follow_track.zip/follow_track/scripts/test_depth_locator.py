#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
depth_locator 的真值自测。上机前必须通过。

用合成深度图构造已知答案，验证：
  T1 正前方 1.2 m 的人  -> Z≈1.2, X≈0
  T2 右侧偏移的人        -> X 为正且与几何一致
  T3 人贴墙（人 1.2 m、墙 2.0 m 同框） -> 选中人而非墙
  T4 只有墙、无人        -> 峰值落在墙上但被尺寸校验拦截 或 记录其行为
  T5 全无效深度          -> invalid
  T6 相机系 -> base_link 变换方向正确

运行：~/follow/venv/bin/python scripts/test_depth_locator.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from depth_locator import DepthLocator, camera_to_base

K = (606.28, 605.50, 322.61, 253.80)
EXTRINSIC = (0.160, 0.0325, 0.242, (-1.5707963, 0.0, -1.5707963))
W, H = 640, 480

fails = []


def check(name, cond, detail=""):
    tag = "PASS" if cond else "FAIL"
    print("  [%s] %s %s" % (tag, name, detail))
    if not cond:
        fails.append(name)


def syn_depth(person_rect=None, person_d=1.2, wall_d=None,
              noise=0.005, seed=7):
    """
    person_rect: (u1, v1, u2, v2) 人在图像中的矩形
    其余像素：wall_d（墙）或 0（无回波）
    """
    rng = np.random.RandomState(seed)
    d = np.zeros((H, W), dtype=np.float32)
    if wall_d is not None:
        d[:] = wall_d
    if person_rect is not None:
        u1, v1, u2, v2 = person_rect
        d[v1:v2, u1:u2] = person_d
    if noise > 0:
        d = d + rng.normal(0, noise, d.shape).astype(np.float32)
    return d


def t1():
    print("T1 正前方 1.2 m")
    rect = (270, 140, 380, 460)
    d = syn_depth(rect, 1.2, wall_d=None)
    loc = DepthLocator()
    r = loc.locate(rect, d, K)
    check("valid", r.valid, r.reason)
    if r.valid:
        check("Z≈1.20", abs(r.Z - 1.2) < 0.02, "Z=%.4f" % r.Z)
        check("X≈0", abs(r.X) < 0.02, "X=%.4f" % r.X)
        check("点数充足", r.n_points > 2000, "n=%d" % r.n_points)


def t2():
    print("T2 右侧偏移的人")
    rect = (430, 140, 540, 460)
    d = syn_depth(rect, 1.2, wall_d=None)
    loc = DepthLocator()
    r = loc.locate(rect, d, K)
    check("valid", r.valid, r.reason)
    if r.valid:
        # 中心 u≈485，X=(485-322.61)*1.2/606.28 ≈ +0.321
        expect = (0.5 * (430 + 540) - K[2]) * 1.2 / K[0]
        check("X 与几何一致", abs(r.X - expect) < 0.05,
              "X=%.4f expect=%.4f" % (r.X, expect))
        check("X 为正", r.X > 0.2, "X=%.3f" % r.X)


def t3():
    print("T3 人贴墙（人 1.2 m 在 2.0 m 墙前）")
    rect = (270, 140, 380, 460)
    d = syn_depth(rect, 1.2, wall_d=2.0)
    loc = DepthLocator()
    r = loc.locate(rect, d, K)
    check("valid", r.valid, r.reason)
    if r.valid:
        check("选中人不是墙", abs(r.Z - 1.2) < 0.05, "Z=%.4f" % r.Z)
        check("峰值在 1.2", abs(r.peak_depth - 1.2) < 0.10,
              "peak=%.3f" % r.peak_depth)


def t4():
    print("T4 框内只有墙（无人）")
    # 整幅 2.0 m 墙面，bbox 圈住墙的一部分
    d = syn_depth(None, wall_d=2.0)
    loc = DepthLocator()
    r = loc.locate((270, 140, 380, 460), d, K)
    # 墙是平整面：深度方差应极小。此处记录其行为，不做硬断言，
    # 阈值须由真机数据定。
    print("    -> valid=%s reason=%s Z=%.3f width=%.3f dstd=%.4f"
          % (r.valid, r.reason, r.Z, r.width_m, r.depth_std))
    if r.valid:
        check("墙面深度方差极小（可作为拒绝依据）", r.depth_std < 0.02,
              "dstd=%.4f" % r.depth_std)


def t5():
    print("T5 全无效深度")
    d = np.zeros((H, W), dtype=np.float32)
    loc = DepthLocator()
    r = loc.locate((270, 140, 380, 460), d, K)
    check("invalid", not r.valid, r.reason)


def t6():
    print("T6 相机系 -> base_link")
    # 光学系正前方 1 m：Z=1 -> base X 方向
    bx, by, bz = camera_to_base(0.0, 0.0, 1.0, EXTRINSIC)
    check("前方 1m -> base X≈1.16", abs(bx - (1.0 + 0.160)) < 0.01,
          "(%.3f, %.3f, %.3f)" % (bx, by, bz))
    check("高度≈0.242（相机安装高）", abs(bz - 0.242) < 0.01, "Z=%.3f" % bz)
    # 光学系右侧 0.5 m：X=0.5 -> base 负 Y（base Y 向左）
    bx2, by2, bz2 = camera_to_base(0.5, 0.0, 1.0, EXTRINSIC)
    check("右侧 0.5m -> base Y≈-0.5+0.0325", abs(by2 - (-0.5 + 0.0325)) < 0.02,
          "(%.3f, %.3f, %.3f)" % (bx2, by2, bz2))


def t7():
    print("T7 复现真机故障：框过大、背景点数反超人体")
    # 真机情形：目标贴近相机，bbox 撑满画面，人体只占中间一块。
    # 背景（1.89 m）入池点数远多于人体（0.32 m），无先验时峰值落到背景。
    bbox = (0, 0, 640, 480)
    person = (250, 100, 400, 470)
    d = syn_depth(person, 0.32, wall_d=1.89, noise=0.004)
    loc = DepthLocator()

    r_free = loc.locate(bbox, d, K)
    print("    无先验     -> valid=%s reason=%s peak=%.2f n=%d"
          % (r_free.valid, r_free.reason, r_free.peak_depth, r_free.n_points))
    check("无先验时峰值落到背景（故障可复现）",
          abs(r_free.peak_depth - 1.89) < 0.10, "peak=%.2f" % r_free.peak_depth)

    r_prior = loc.locate(bbox, d, K, prior_d=0.32)
    print("    prior=0.32 -> valid=%s Z=%.3f peak=%.2f n=%d"
          % (r_prior.valid, r_prior.Z, r_prior.peak_depth, r_prior.n_points))
    check("加先验后锁定人体", r_prior.valid and abs(r_prior.Z - 0.32) < 0.03,
          "Z=%.3f" % r_prior.Z)

    r_bad = loc.locate(bbox, d, K, prior_d=2.90)
    print("    prior=2.90（错误先验）-> valid=%s reason=%s Z=%.3f"
          % (r_bad.valid, r_bad.reason, r_bad.Z))


if __name__ == "__main__":
    print("=" * 52)
    print("depth_locator 真值自测")
    print("=" * 52)
    t1(); t2(); t3(); t4(); t5(); t6(); t7()
    print("=" * 52)
    if fails:
        print("失败 %d 项: %s" % (len(fails), ", ".join(fails)))
        sys.exit(1)
    print("全部通过")
