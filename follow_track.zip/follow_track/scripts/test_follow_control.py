# -*- coding: utf-8 -*-
"""follow_control 自测。纯合成场景，不需要相机、数据集或 ROS。

覆盖安全底线与可达性：
    T1 正前 1.2 m 静止        -> 不动作
    T2 正前 2.0 m 静止        -> 前进，直行
    T3 正前 0.6 m（太近）      -> 停车，绝不前进
    T4 左前 45°               -> 左转
    T5 右前 45°               -> 右转
    T6 转角不超 35°、omega 不超阿克曼极限
    T7 目标在后方             -> 停车
    T8 估计不可信             -> 停车
    T9 抖动输入               -> 转向变化率受限，不抽搐
    T10 1.0 m/s 前馈          -> 速度提升但不超上限
    T11 单帧速度变化受限       -> 不出现阶跃
    T12 侧方过近              -> 低速转向脱离，不加速
"""

import math

from follow_control import FollowController, omega_limit

OK, FAIL = [], []


def check(name, cond, detail=""):
    (OK if cond else FAIL).append(name)
    print("  [%s] %s%s" % ("PASS" if cond else "FAIL", name,
                           ("  " + detail) if detail else ""))


DT = 1.0 / 30.0


def run(ctrl, steps, x, y, vx=0.0, vy=0.0, reliable=True, t0=0.0):
    out = None
    for k in range(steps):
        out = ctrl.compute(t0 + k * DT, x, y, vx, vy, reliable)
    return out


def t1():
    print("T1 正前 1.2 m 静止")
    c = FollowController()
    o = run(c, 60, 1.20, 0.0)
    print("    mode=%s v=%.3f delta=%.3f %s" % (o["mode"], o["v"], o["delta"], o["reason"]))
    check("不动作", o["v"] < 1e-6, "v=%.3f" % o["v"])


def t2():
    print("T2 正前 2.0 m 静止")
    c = FollowController()
    o = run(c, 90, 2.00, 0.0)
    print("    mode=%s v=%.3f delta=%.1f°" % (o["mode"], o["v"], math.degrees(o["delta"])))
    check("前进", o["v"] > 0.10, "v=%.3f" % o["v"])
    check("直行", abs(math.degrees(o["delta"])) < 2.0, "%.1f°" % math.degrees(o["delta"]))
    check("不超速", o["v"] <= 0.45 + 1e-6, "v=%.3f" % o["v"])


def t3():
    print("T3 正前 0.6 m（太近）")
    c = FollowController()
    o = run(c, 60, 0.60, 0.0)
    print("    mode=%s v=%.3f %s" % (o["mode"], o["v"], o["reason"]))
    check("后退保持距离", o["v"] < -1e-6, "v=%.3f" % o["v"])
    check("绝不前进", o["v"] <= 0.0, "v=%.3f" % o["v"])


def t3b():
    print("T3b 正前 0.45 m（近距保护）")
    c = FollowController()
    o = run(c, 60, 0.45, 0.0)
    print("    mode=%s v=%.3f %s" % (o["mode"], o["v"], o["reason"]))
    check("停车", o["v"] == 0.0, "v=%.3f" % o["v"])
    check("原因为近距保护", "近距保护" in o["reason"], o["reason"])


def t4():
    print("T4 左前 45°（1.5 m）")
    c = FollowController()
    d = 1.5
    o = run(c, 60, d * math.cos(math.radians(45)), d * math.sin(math.radians(45)))
    print("    delta=%+.1f° v=%.3f" % (math.degrees(o["delta"]), o["v"]))
    check("左转", o["delta"] > 0.01, "%.1f°" % math.degrees(o["delta"]))


def t5():
    print("T5 右前 45°（1.5 m）")
    c = FollowController()
    d = 1.5
    o = run(c, 60, d * math.cos(math.radians(45)), -d * math.sin(math.radians(45)))
    print("    delta=%+.1f° v=%.3f" % (math.degrees(o["delta"]), o["v"]))
    check("右转", o["delta"] < -0.01, "%.1f°" % math.degrees(o["delta"]))


def t6():
    print("T6 转角与角速度上限")
    c = FollowController()
    worst_d, worst_ratio = 0.0, 0.0
    for ang in range(-80, 81, 5):
        for d in (0.7, 1.2, 2.0, 3.0):
            cc = FollowController()
            a = math.radians(ang)
            o = run(cc, 90, d * math.cos(a), d * math.sin(a))
            worst_d = max(worst_d, abs(math.degrees(o["delta"])))
            lim = omega_limit(o["v"], 0.315, math.radians(35.0))
            if lim > 1e-6:
                worst_ratio = max(worst_ratio, abs(o["omega"]) / lim)
    print("    最大转角 %.1f°   omega/极限 最大 %.2f" % (worst_d, worst_ratio))
    check("转角 <= 35°", worst_d <= 35.0 + 0.1, "%.1f°" % worst_d)
    check("omega 不超阿克曼极限", worst_ratio <= 1.0 + 1e-2, "%.2f" % worst_ratio)


def t7():
    print("T7 目标在后方（165°，超过 rear_zone=150°）")
    c = FollowController()
    a = math.radians(165)
    o = run(c, 60, 1.5 * math.cos(a), 1.5 * math.sin(a))
    print("    mode=%s v=%.3f %s" % (o["mode"], o["v"], o["reason"]))
    check("停车", o["v"] < 1e-6, "v=%.3f" % o["v"])
    check("原因为后方", "后方" in o["reason"], o["reason"])


def t7b():
    print("T7b 目标在侧后方（135°，新 rear_zone 内应继续跟）")
    c = FollowController()
    a = math.radians(135)
    o = run(c, 60, 1.5 * math.cos(a), 1.5 * math.sin(a))
    print("    mode=%s v=%.3f %s" % (o["mode"], o["v"], o["reason"]))
    check("不再判后方", "后方" not in o["reason"], o["reason"])


def t8():
    print("T8 估计不可信")
    c = FollowController()
    o = run(c, 60, 2.0, 0.0, reliable=False)
    print("    mode=%s v=%.3f %s" % (o["mode"], o["v"], o["reason"]))
    check("停车", o["v"] < 1e-6, "v=%.3f" % o["v"])


def t9():
    print("T9 抖动输入：转向变化率")
    c = FollowController()
    deltas = []
    for k in range(120):
        # 目标在 1.3 m、±8° 之间来回跳
        a = math.radians(8.0 if k % 2 == 0 else -8.0)
        o = c.compute(k * DT, 1.3 * math.cos(a), 1.3 * math.sin(a))
        deltas.append(o["delta"])
    d = [abs(b - a) for a, b in zip(deltas, deltas[1:])]
    dmax = max(d)
    span = max(deltas) - min(deltas)
    print("    单帧 delta 最大变化 %.3f rad  总摆幅 %.3f rad" % (dmax, span))
    check("单帧变化 <= 0.26 rad", dmax <= 0.26, "%.3f" % dmax)
    check("总摆幅受限（<0.5 rad）", span < 0.5, "%.3f" % span)


def t10():
    print("T10 1.0 m/s 前馈")
    c = FollowController()
    o = run(c, 90, 2.0, 0.0, vx=1.0)
    print("    v=%.3f（上限 0.45）" % o["v"])
    check("提速但不超限", 0.44 <= o["v"] <= 0.45 + 1e-6, "v=%.3f" % o["v"])


def t11():
    print("T11 单帧速度变化受限")
    c = FollowController()
    c.compute(0.0, 1.20, 0.0)
    jump = c.compute(DT, 3.00, 0.0)      # 一步从 1.2 跳到 3.0
    # 起步下限 v_min 允许绕过加速度限制（否则极低速起步会卡住）
    cap = max(c.max_accel * DT, c.v_min)
    print("    v=%.3f（max_accel=%.1f, dt=%.3f -> 上限 %.3f，v_min=%.2f）"
          % (jump["v"], c.max_accel, DT, c.max_accel * DT, c.v_min))
    check("不出现阶跃", jump["v"] <= cap + 1e-6, "v=%.3f" % jump["v"])


def t12():
    print("T12 侧方过近（0.7 m，偏 60°）")
    c = FollowController()
    a = math.radians(60)
    o = run(c, 60, 0.7 * math.cos(a), 0.7 * math.sin(a))
    print("    mode=%s v=%.3f delta=%+.1f° %s"
          % (o["mode"], o["v"], math.degrees(o["delta"]), o["reason"]))
    check("绝不前进", o["v"] <= 0.0, "v=%.3f" % o["v"])
    check("仍在转向", abs(o["delta"]) > 1e-3, "%.1f°" % math.degrees(o["delta"]))


if __name__ == "__main__":
    print("=" * 58)
    print("follow_control 自测")
    print("=" * 58)
    for fn in (t1, t2, t3, t3b, t4, t5, t6, t7, t7b, t8, t9, t10, t11, t12):
        fn()
        print()
    print("=" * 58)
    print("通过 %d  失败 %d" % (len(OK), len(FAIL)))
    if FAIL:
        print("失败项: %s" % ", ".join(FAIL))
    print("=" * 58)
