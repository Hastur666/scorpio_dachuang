# -*- coding: utf-8 -*-
"""
S3：目标状态估计 —— 卡尔曼滤波 + 马氏门控。

把逐帧独立、带噪声的 3D 观测，转成连续的位置与速度序列。

状态  [x, y, vx, vy]   车体系，单位 m 与 m/s
观测  [x, y]           来自 depth_locator，无观测时传 None

为什么是四维而非 AB3DMOT 的七维：
    行人的俯仰、身高、体宽随姿态剧变，纳入状态只会引入噪声；
    跟随控制只需要平面位置与速度。维数降低，数值稳定性反而更好。

为什么门控比增益重要：
    低通只能把跳变抹平，错误值仍然进入状态；马氏门控是根本不接受
    这个值。真机实测出现过 Z 在 0.32 / 1.89 m 间来回跳 4 次的情形，
    此类观测与预测的位置突变超过 1 m，门控直接拒绝。
"""

import numpy as np

# 卡方分布 95% 分位：观测为 2 维（x, y），故自由度 2
CHI2_95_DF2 = 5.991


class TrackFilter(object):
    """匀速模型卡尔曼滤波，处理变长间隔与观测缺失。

    参数
        sigma_obs   观测噪声标准差（m）。取 bbox + 直方图峰值 + 中位数
                    这条链路在 1-2 m 距离的实际误差量级
        q_acc       加速度噪声谱密度（m^2/s^3）。人行走的加速度波动
                    约 0.5-1.0 m/s^2，取平方即 0.25-1.0
        gate_chi2   马氏距离门限，默认 2 自由度 95% 分位
        max_dt      单次预测的最大时间跨度（s）。超过则视为中断，
                    截断 dt 并放大速度不确定性，避免一次长卡顿把
                    状态推到不合理位置
    """

    def __init__(self, sigma_obs=0.08, q_acc=0.6, gate_chi2=CHI2_95_DF2,
                 max_dt=0.50, init_pos_std=0.50, init_vel_std=1.50,
                 max_speed=1.20, reliable_pos_std=0.15,
                 max_consec_reject=8):
        self.sigma_obs = float(sigma_obs)
        self.q = float(q_acc)
        self.gate_chi2 = float(gate_chi2)
        self.max_dt = float(max_dt)
        self.init_pos_std = float(init_pos_std)
        self.init_vel_std = float(init_vel_std)
        # 控制层安全限幅：人正常步速上限，超出部分不直接喂给底盘
        self.max_speed = float(max_speed)
        # 位置标准差超过此值即认为估计不可直接用于闭环
        self.reliable_pos_std = float(reliable_pos_std)
        # 连续拒绝兜底：超过该次数就用新观测重定位。没有这条，一次超过
        # 门宽的真实跳变会让滤波器永久停在旧预测上，车彻底不动。
        self.max_consec_reject = int(max_consec_reject)
        self.n_consec_reject = 0
        self.n_reinit = 0

        # 4 维状态与协方差
        self.x = np.zeros(4, dtype=np.float64)
        self.P = np.eye(4, dtype=np.float64)

        # 观测矩阵：只有位置可观测
        self.H = np.zeros((2, 4), dtype=np.float64)
        self.H[0, 0] = 1.0
        self.H[1, 1] = 1.0

        self.R = np.eye(2, dtype=np.float64) * (self.sigma_obs ** 2)

        self.initialized = False
        self.last_t = None
        self.frames_since_obs = 0     # 距上次被接受的观测过了多少步

        # 诊断计数（当前段）
        self.n_update = 0          # 被接受的观测
        self.n_gate_reject = 0     # 被门控拒绝的观测
        self.n_predict_only = 0    # 无观测、仅预测的步数
        self.n_dt_clamped = 0      # dt 被截断的次数
        self.nis_history = []      # 归一化新息平方，用于调参

        # 累计计数：reset 不清零，供 stats() 汇总全生命周期
        self.cum_n_update = 0
        self.cum_n_gate_reject = 0
        self.cum_n_predict_only = 0

    # ------------------------------------------------------------------
    # 基础操作
    # ------------------------------------------------------------------
    def reset(self, z=None, t=None):
        """重置滤波器。目标 ID 变化或严重失锁后调用；不继承旧状态。

        段内计数先并入累计量：ID 切换不能把已经发生的门控拒绝、
        纯预测步数从统计里抹掉（真机曾因此误报"门控拒绝 0 次"）。
        """
        self.cum_n_update += self.n_update
        self.cum_n_gate_reject += self.n_gate_reject
        self.cum_n_predict_only += self.n_predict_only

        self.x = np.zeros(4, dtype=np.float64)
        self.P = np.diag([self.init_pos_std ** 2, self.init_pos_std ** 2,
                          self.init_vel_std ** 2, self.init_vel_std ** 2])
        self.initialized = False
        self.last_t = t
        self.frames_since_obs = 0
        self.n_consec_reject = 0
        self.n_update = 0
        self.n_gate_reject = 0
        self.n_predict_only = 0
        # nis_history 与 n_dt_clamped 跨段保留：全生命周期分布才有统计意义
        if z is not None:
            self._init_with(z)

    def _init_with(self, z):
        """用首个观测初始化：位置取观测，速度置零（不确定性大）。"""
        self.x[0] = float(z[0])
        self.x[1] = float(z[1])
        self.x[2] = 0.0
        self.x[3] = 0.0
        self.P = np.diag([self.sigma_obs ** 2,
                          self.sigma_obs ** 2,
                          self.init_vel_std ** 2,
                          self.init_vel_std ** 2])
        self.initialized = True

    def _Q(self, dt):
        """连续白噪声加速度模型的离散化。"""
        dt2 = dt * dt
        dt3 = dt2 * dt
        dt4 = dt2 * dt2
        q = self.q
        Q = np.zeros((4, 4), dtype=np.float64)
        Q[0, 0] = q * dt4 / 4.0
        Q[1, 1] = q * dt4 / 4.0
        Q[0, 2] = Q[2, 0] = q * dt3 / 2.0
        Q[1, 3] = Q[3, 1] = q * dt3 / 2.0
        Q[2, 2] = q * dt2
        Q[3, 3] = q * dt2
        return Q

    def predict(self, dt):
        """按 dt 推进。dt 超限时截断，并额外放大速度不确定性。"""
        if dt <= 0.0:
            return
        clamped = False
        if dt > self.max_dt:
            dt = self.max_dt
            clamped = True
            self.n_dt_clamped += 1

        F = np.eye(4, dtype=np.float64)
        F[0, 2] = dt
        F[1, 3] = dt

        self.x = F.dot(self.x)
        self.P = F.dot(self.P).dot(F.T) + self._Q(dt)

        if clamped:
            # 中断期内真实运动未知，放大速度方差以免后续观测全被门控拒绝
            self.P[2, 2] += (self.q * self.max_dt) ** 2
            self.P[3, 3] += (self.q * self.max_dt) ** 2

        # 对称化，抑制长时间迭代的数值漂移
        self.P = 0.5 * (self.P + self.P.T)

    def update(self, z, obs_std=None):
        """用观测修正状态。

        参数
            obs_std  该次观测的标准差（米）。None 用构造时的 sigma_obs。
                     雷达观测的簇中心与深度测的身体表面有系统差，
                     噪声明显大于深度，需要单独给一个更大的值，
                     否则会被马氏门判成野值，等于没接管。

        返回 (accepted, nis)
            accepted  False 表示被门控拒绝，状态未变
            nis       归一化新息平方，拒绝时也返回，便于事后分析
        """
        z = np.asarray(z, dtype=np.float64).reshape(2)

        if not self.initialized:
            self._init_with(z)
            self.n_update += 1
            return True, 0.0

        R = self.R if obs_std is None else np.eye(2) * (float(obs_std) ** 2)

        y = z - self.H.dot(self.x)                 # 新息
        S = self.H.dot(self.P).dot(self.H.T) + R
        try:
            S_inv = np.linalg.inv(S)
        except np.linalg.LinAlgError:
            return False, float("inf")

        nis = float(y.dot(S_inv).dot(y))
        self.nis_history.append(nis)
        # 长跑防止无限增长：只保留最近 2 万条，足够拟合分布
        if len(self.nis_history) > 20000:
            del self.nis_history[:10000]

        if nis > self.gate_chi2:
            self.n_gate_reject += 1
            self.n_consec_reject += 1
            if self.n_consec_reject >= self.max_consec_reject:
                # 观测连续 N 次都落在门外，说明不是单帧野值而是目标真跳了
                # （或车体位姿漂移）。重定位，避免永久卡死。
                self._reinit_from(z)
                return True, nis
            return False, nis

        self.n_consec_reject = 0

        K = self.P.dot(self.H.T).dot(S_inv)
        self.x = self.x + K.dot(y)

        # Joseph 形式：保证协方差对称正定
        I_KH = np.eye(4) - K.dot(self.H)
        self.P = I_KH.dot(self.P).dot(I_KH.T) + K.dot(R).dot(K.T)
        self.P = 0.5 * (self.P + self.P.T)

        self.n_update += 1
        return True, nis

    def _reinit_from(self, z):
        """连续拒绝兜底：位置直接拉到观测值，速度减半，协方差复位。

        不整段 reset 是为了保留"人可能在动"的先验，避免速度瞬间归零让
        控制输出突跳；位置协方差放大后门控自然变宽，下一帧容易接住。
        """
        self.x[0] = float(z[0])
        self.x[1] = float(z[1])
        self.x[2] *= 0.5
        self.x[3] *= 0.5
        self.P = np.diag([self.init_pos_std ** 2, self.init_pos_std ** 2,
                          self.init_vel_std ** 2, self.init_vel_std ** 2])
        self.n_consec_reject = 0
        self.n_reinit += 1
        self.n_update += 1

    # ------------------------------------------------------------------
    # 主接口
    # ------------------------------------------------------------------
    def step(self, t, z=None, obs_std=None):
        """推进到时刻 t。

        z 为 None 时只预测，状态照常前进 —— 这是"深度短暂失效仍输出
        连续轨迹"的关键：控制层不会因为某一帧没观测而拿到断点。
        obs_std 为本次观测的标准差，雷达观测要比深度给更大的值。

        返回 dict，供上层直接使用：
            t, x, y, vx, vy, pos_std, speed, accepted, nis, initialized
        """
        if self.last_t is None:
            self.last_t = t

        dt = t - self.last_t
        self.last_t = t

        if not self.initialized:
            if z is not None:
                self._init_with(z)
                return self._snapshot(t, True, 0.0)
            # 尚无观测：保持未初始化，位置无意义
            return self._snapshot(t, False, 0.0)

        self.predict(dt)

        accepted = False
        nis = 0.0
        if z is not None:
            accepted, nis = self.update(z, obs_std=obs_std)
        else:
            self.n_predict_only += 1

        self.frames_since_obs = 0 if accepted else (self.frames_since_obs + 1)

        return self._snapshot(t, accepted, nis)

    def _snapshot(self, t, accepted, nis):
        pos_std = float(np.sqrt(max(1e-12, 0.5 * (self.P[0, 0] + self.P[1, 1]))))
        vel_std = float(np.sqrt(max(1e-12, 0.5 * (self.P[2, 2] + self.P[3, 3]))))
        speed = float(np.hypot(self.x[2], self.x[3]))
        # 可信 = 位置够准 + 最近确有观测支撑。纯预测超过 10 步即降级
        reliable = bool(self.initialized
                        and pos_std <= self.reliable_pos_std
                        and self.frames_since_obs <= 10)
        return {
            "t": t,
            "x": float(self.x[0]),
            "y": float(self.x[1]),
            "vx": float(self.x[2]),
            "vy": float(self.x[3]),
            "pos_std": pos_std,
            "vel_std": vel_std,
            "speed": speed,
            # 供控制层直接使用的限幅速度：诊断仍看 speed，闭环用这个
            "speed_capped": float(min(speed, self.max_speed)),
            "reliable": reliable,
            "frames_since_obs": int(self.frames_since_obs),
            "accepted": bool(accepted),
            "nis": float(nis),
            "initialized": bool(self.initialized),
        }

    # ------------------------------------------------------------------
    # 诊断
    # ------------------------------------------------------------------
    def stats(self):
        """全生命周期统计。跨 reset 累计，ID 切换不会抹掉历史事件。"""
        nis = np.asarray(self.nis_history, dtype=np.float64) if self.nis_history else np.zeros(1)
        n_upd = self.cum_n_update + self.n_update
        n_rej = self.cum_n_gate_reject + self.n_gate_reject
        return {
            "n_update": n_upd,
            "n_gate_reject": n_rej,
            "n_predict_only": self.cum_n_predict_only + self.n_predict_only,
            "n_dt_clamped": self.n_dt_clamped,
            "n_reinit": self.n_reinit,
            "gate_reject_ratio": float(n_rej) / max(1, n_rej + n_upd),
            "nis_median": float(np.median(nis)),
            "nis_p95": float(np.percentile(nis, 95)),
        }
